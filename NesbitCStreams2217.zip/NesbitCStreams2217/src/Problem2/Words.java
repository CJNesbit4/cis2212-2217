package Problem2;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Complete the methods below. You may add helper methods
 * as you require.
 */
public class Words
{      
   /**
    * The noLetterRepeated method reads all of the words 
    * in filename and returns a list of all words with 
    * length of at least ten, in which no letter is repeated.
    * You may assume that filename has one word per line.
    */
   public static List<String> noLetterRepeated(String filename)
   {
      List<String> result = new ArrayList<>();
      try (Stream<String> lines = Files.lines(Paths.get("words.txt")))
      {
    	result = lines.filter(w -> !w.endsWith("'s"))
    				  .filter(w -> w.length() >= 10)
    	              .filter(w -> allLettersUnique(w.toLowerCase()))
    	              .collect(Collectors.toList());
    	  
      } catch (IOException ex) {
    	  System.out.println("Oopsies! Stream didn't like that :( and here is why");
    	  ex.printStackTrace();
      }
      
      return result;
   }
   
   /**
    * The longestWord method takes a Stream<String> and
    * returns the longest word in the stream.
    */
   public static String longestWord(Stream<String> stream)
   {
      String result = stream
    		  .max(Comparator.comparing(String::length))
    		  .orElse("");

      return result;
   }
   
   /**
    * Given a Stream<String> and a length, 
    * returns the number of words of that length in the stream.
    */
   public static long wordCount(Stream<String> stream, int len)
   {
      long result = stream
    		  .filter(w -> w.length() == len)
    		  .filter(w -> !w.endsWith("'s"))
    		  .count();
      
      return result;
   }
   

   //slow method i know but i cant be asked to think of or find a quicker method
   //the program is fast enough with this anyways
   private static boolean allLettersUnique(String str) {
	   for (int i = 0; i < str.length(); i++) {
		   for (int j = i + 1; j < str.length(); j++) {
			   if (str.charAt(i) == str.charAt(j)) {
				   return false;
			   }
		   }
	   }
	   return true;
   }
   
   
}
