package Problem3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MoviesTester {
	public static void main(String[] args) throws IOException
	   {
	      List<Movie> moviesList = Movies.readMovies("movies.txt");
	 
	      // You'll write this method
	      List<String> initialWords = commonInitialWords(moviesList.stream(), true);
	      
	      System.out.println("Size: " + initialWords.size());
	      System.out.println("Expected: 100");
	      System.out.println("Word #1: " + initialWords.get(0));
	      System.out.println("Expected: The");
	      System.out.println("Word #2: " + initialWords.get(1));
	      System.out.println("Expected: A");
	      System.out.println("Word #3: " + initialWords.get(2));
	      System.out.println("Expected: In");
	      System.out.println("Word #4: " + initialWords.get(3));
	      System.out.println("Expected: I");
	      System.out.println("Word #5: " + initialWords.get(4));
	      System.out.println("Expected: Love");
	      System.out.println("Word #100: " + initialWords.get(99)); 
	      System.out.println("Expected: She"); 
	      
	      /*
	      for(int i = 0; i < 100; i++) {
	    	  System.out.println(i + " " + initialWords.get(i));
	      } */
	      
	      //alphabetically
	      List<String> alphaSort = commonInitialWords(moviesList.stream(), false);
	      
	      for(int i = 0; i < 100; i++) {
	    	  System.out.println(i + " " + alphaSort.get(i));
	      }
	   }
	   
	   /**
	    * Given a Stream<Movie> return the 100 most common
	    * starting words.
	    */
	   public static List<String> commonInitialWords(Stream<Movie> stream, boolean count) {
		  if (count) {
			  List<String> result = stream
					   .map(m -> m.getTitle())
					   .map(title -> getFirstWord(title))
					   .collect(Collectors.groupingBy(word -> word.toLowerCase(), Collectors.counting()))
					   .entrySet()
					   .stream()
					   .sorted((entry1,entry2) -> Long.compare(entry2.getValue(), entry1.getValue()))
					   .limit(100)
					   .map(Map.Entry::getKey)
					   .collect(Collectors.toList());
			   return result; 
		  } 
		  else { //alphabetically
			  List<String> result = stream
					   .map(m -> m.getTitle())
					   .map(title -> getFirstWord(title))
					   .map(word -> word.replaceAll("[^a-zA-Z]", "")) //https://stackoverflow.com/questions/11149759/remove-all-non-alphabetic-characters-from-a-string-array-in-java
					   .collect(Collectors.groupingBy(word -> word, Collectors.counting())) //no lowercase conversion so it filters A > a
					   .entrySet()
					   .stream()
					   .sorted(Map.Entry.comparingByKey())
					   .limit(100)
					   .map(Map.Entry::getKey)
					   .collect(Collectors.toList());
			   return result; 
		  }
		  

	   }
	   
	   private static String getFirstWord(String str) {
		   if (str == null || str.isEmpty()) { return ""; }
		   
		   String array[] = str.split(" ", 2);
		   return array[0];
		   
	   }
}
