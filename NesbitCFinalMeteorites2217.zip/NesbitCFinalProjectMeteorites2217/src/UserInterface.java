//CJ Nesbit
//NASA Meteorites Final

import com.google.gson.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.NoSuchFileException;
import java.nio.file.Paths;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UserInterface {
	private String str;
	private Meteorite[] data;
	
	public UserInterface() {
		this.setStr("");
		
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("data/save.bin"))) {
			this.setData((Meteorite[]) in.readObject());
		} catch (ClassNotFoundException ex) {
			System.out.println("Error loading the Meteorite class.");
			System.out.println("Please restart or restore the program to a previous stable state.");
		} catch (StreamCorruptedException ex) {
			System.out.println("Error: Corrupted Stream.");
			System.out.println("You may have tried to load a binary file that was generated from other software.");
			System.out.println("Or your file was saved improperly and was corrupted.");
		} catch (FileNotFoundException ex) {
			this.setData(new Meteorite[0]);
			//just empties the array for now if the user has not created the save file
		} catch (IOException ex) {
			System.out.println("Error: General I/O Error.");
			System.out.println("The file may have been corrupted during saving or tampered with at some point.");
		} catch (SecurityException ex) {
			System.out.println("Error: File Security Error.");
			System.out.println("The program may not have sufficient permissions to read the file.");
		} catch (NullPointerException ex) {
			System.out.println("Error: Null Pointer Exception.");
			System.out.println("The file requested to load was null.");
		} catch (IllegalStateException ex) {
			System.out.println("Error: Illegal state exception loading the Object Input Stream. Details:");
			ex.printStackTrace();
		} 
		
		//corrects all the years using setYear
		for (int i = 0; i < this.getData().length; i++) {
			this.getData()[i].setYear(this.getData()[i].getYear());
		}
		//I couldn't find this bug until I found out that Gson doesn't use the setters which is annoying
		//just adds a tiny bit more processing time to load the file :/
	}
	
	public String getStr() {
		return this.str;
	}
	
	public void setStr(String str) {
		this.str = str;
	}
	
	public Meteorite[] getData() {
		return this.data;
	}
	
	public void setData(Meteorite[] data) {
		this.data = data;
	}
	
	public void searchName(String name) {
		Stream<Meteorite> meteorites = Stream.of(this.getData());
		Meteorite result = meteorites
			.filter(m -> m.getName().equalsIgnoreCase(name)) 
			.limit(1) //sort of assuming that there are no duplicate named ones
			.toList()
			.stream()
			.findFirst()
			.orElse(null);
		
		if (result != null) {
			System.out.println(result.display());
		} 
		else {
			System.out.println("No Meteorite was found with name " + name + ".");
		}
		
	}
	
	public void searchID(int id) {
		Stream<Meteorite> meteorites = Stream.of(this.getData());
		Meteorite result = meteorites
			.filter(m -> m.getId() == id)
			.limit(1)
			.toList()
			.stream() //i guess you could also delete these lines and instead use a List for the results
			.findFirst()
			.orElse(null);
		
		if (result != null) { //then put if(result.length != 0) and grab result.get(1). i just prefer staying inside the stream the whole time
			System.out.println(result.display());
		} 
		else {
			System.out.println("No Meteorite was found with ID " + id + ".");
		}
	}
	
	public List<Meteorite> getMassStream(int lim) {
		List<Meteorite> result = Stream.of(this.getData())
				.sorted((a,b) -> Double.compare(b.getMass(), a.getMass()))
				.limit(lim)
				.collect(Collectors.toList());
		
		return result;
	}
	
	public List<Meteorite> getYearStream(int lim) {
		List<Meteorite> result = Stream.of(this.getData())
				.filter(y -> !y.getYear().isEmpty())  //this filters any null years referenced in Meteorite's setYear method
				.sorted((a,b) -> {
					String y1 = a.getYear();
					String y2 = b.getYear();
					//if there is a way to fit this in one lambda expression without the brackets I can't figure out the syntax for it
					return Integer.compare(Integer.parseInt(y2), Integer.parseInt(y1));
				})
				.limit(lim)
				.collect(Collectors.toList());
		
		return result;
	}
	
	public List<Map.Entry<String, Long>> getClassStream() {
		//there might be a quicker way to do this without using two streams
		//but if there is I couldn't figure it out
		//the zybooks problems only did sorting or counting but never both at a time
		
		Map<String, Long> freq = Stream.of(this.getData())
				.map(Meteorite::getRecClass)
				.collect(Collectors.groupingBy(x -> x, Collectors.counting()));
		
		List<Map.Entry<String, Long>> sort = freq.entrySet().stream()
				.sorted((a,b) -> Long.compare(b.getValue(), a.getValue())) 
				.collect(Collectors.toList());
		//I just used a map to store the recclass and the freqencies but it honestly might be doable with just one List
		//but again if that is possible I couldn't figure it out and this is the only solution I could make that worked
		//if you read the comments let me know if this is close enough to the intended solution though
		//i spent a lot of time on the movies project and that one worked so I just basically copied my solution for that
		
		return sort;
	}
	

	public void go() {
		int userSelect = -1; Scanner input = new Scanner(System.in);
		
		while (userSelect != 0) {
			System.out.println("");
			System.out.println("Welcome to the NASA Meteorite tracking database.");
			System.out.println("");
			System.out.println("Here is the menu of choices: ");
			System.out.println("    0) Quit");
			System.out.println("    1) Import meteorite data from a JSON file");
			System.out.println("    2) Display the meteorite data");
			System.out.println("    3) Export the meteorite data to a file");
			System.out.println("    4) Find a meteorite by name");
			System.out.println("    5) Find a meteorite by ID");
			System.out.println("    6) List the largest meteorites");
			System.out.println("    7) List the most recent meteorites by year");
			System.out.println("    8) List the meteorite classes");
			System.out.print("Enter your choice: ");
			
			do {
				try {
					userSelect = input.nextInt();
				} catch (InputMismatchException ex) {
					System.out.println("Error: Enter a valid integer for your selection.");
					userSelect = 0; //program terminates
				}
		
				if (userSelect < 0 || userSelect > 8) {
					//this infrastructure isn't exactly necessary as the default switch handles it
					//but this at least loops instead of terminating immediately
					System.out.print("Error: Please enter a number between 0-8: ");
				}
			} while (userSelect < 0 || userSelect > 8);
			
			switch (userSelect) {
			case 0: 
				break;
			case 1: 
				this.setStr(""); //empties the string before loading
				try { 
					
					String userFileName = "";
					System.out.print("Enter the name of the file you wish to load from, or enter nothing to load the default (data/NASA_Meteorite.json): ");
					
					input.nextLine();
					userFileName = input.nextLine();
					if (userFileName == "") {
						this.setStr(Files.readString(Paths.get("data/NASA_Meteorite.json")));
					} else {
						this.setStr(Files.readString(Paths.get(userFileName)));
					}
					
					
					Gson gson = new Gson();
					this.setData(gson.fromJson(this.getStr(), Meteorite[].class));
						
					System.out.println(this.getData().length + " records processed.");
					
				} catch (InvalidPathException ex) {
					System.out.println("Error: The provided file path could not be converted into a Path object.");
				} catch (OutOfMemoryError ex) {
					System.out.println("Error: The file is too large to be read into the program.");
				} catch (NoSuchFileException ex) {
					System.out.println("Error: The system could not find the file specified.");
				} catch (IOException ex) {
					System.out.println("Error: General I/O Exception.");
				} catch (SecurityException ex) {
					System.out.println("Error: The system does not have sufficient permissions to access the file.");
				} catch (JsonSyntaxException ex) {
					System.out.println("Error: The file was loaded but was not in a readable JSON structure.");
				}
				
				
				break;
			case 2: 
				for (Meteorite item : this.getData()) {
					System.out.println(item.toString());
				}
				break;
			case 3: 
				try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("data/save.bin"))) {
					out.writeObject(getData());
					System.out.println("Succesfully exported the meteorite data. This save will be automatically restored if the program is restarted.");
				} catch (IOException ex) {
        			System.out.println("Error: General I/O Error when writing the file.");
        			System.out.println("The file corrupted when attempting to write the stream header, or a serialization error occured. Please try to save again.");
        		} catch (SecurityException ex) {
        			System.out.println("Error: File Security Error.");
        			System.out.println("The program may not have sufficient permissions to read the file.");
        		} catch (NullPointerException ex) {
        			System.out.println("Error: Null Pointer Exception.");
        			System.out.println("The file requested to load was null.");
        		}
				break;
			case 4:
				input.nextLine(); //blocks the newline from entering 4
				System.out.print("Enter the name of the meteorite you wish to search for: ");
				String search = input.nextLine();
				
				searchName(search);
				break;
			case 5: 
				input.nextLine();
				System.out.print("Enter the ID of the meteorite you wish to search for: ");
				try {
					int userID = input.nextInt();
					searchID(userID);
				} catch (InputMismatchException ex) {
					System.out.println("Error: Enter a valid integer for your selection.");
					input.nextLine();
				}
				break;
			case 6: 
				input.nextLine();
				System.out.print("How many of the largest meteorites do you want to see? ");
				try {
					int userMassNum = input.nextInt(); 
					if (userMassNum < 1 || userMassNum > 1000) {
						throw new IllegalArgumentException("Your number is either too small or more than the amount of meteorites loaded in the data.");
					}
					
					List<Meteorite> massResult = getMassStream(userMassNum);
					
					System.out.println("Largest " + userMassNum + " meteorites: ");
					for (int i = 0; i < userMassNum; i++) {
						System.out.println(massResult.get(i).display());
					}
				} catch (InputMismatchException ex) {
					System.out.println("Error: Enter a valid integer for your selection.");
					input.nextLine();
				} catch (IllegalArgumentException ex) {
					System.out.println(ex.getMessage());
				}
				
				break;
			case 7: 
				input.nextLine();
				System.out.print("How many of the largest meteorites do you want to see? ");
				try {
					int userYearNum = input.nextInt(); 
					if (userYearNum < 1 || userYearNum > 1000) {
						throw new IllegalArgumentException("Your number is either too small or more than the amount of meteorites loaded in the data.");
					}
					
					List<Meteorite> yearResult = getYearStream(userYearNum);
					
					System.out.println("Largest 5 meteorites: ");
					for (int i = 0; i < yearResult.size(); i++) {
						System.out.println(yearResult.get(i).display());
					}
				} catch (InputMismatchException ex) {
					System.out.println("Error: Enter a valid integer for your selection.");
					input.nextLine();
				} catch (IllegalArgumentException ex) {
					System.out.println(ex.getMessage());
				}
				
				break;
			case 8: 
				List<Map.Entry<String, Long>> sort = getClassStream();
				
				System.out.println("Meteorite classes:");
				System.out.println("Count  Classification");
				System.out.println("=====  ====================");
				for (int i = 0; i < sort.size(); i++) { //sort.size should always be 1000 but just in case the json gets modified or something I'm using the actual size
					Map.Entry<String, Long> current = sort.get(i);
					
					String recClass = current.getKey();
					Long count = current.getValue();
					
					System.out.println(count + "  " + recClass);
				}
				
				break;
			default:
				break;
			}
		}
		System.out.println("Thank you for using the NASA Meteorite tracking database.");
		input.close();
	}
	
	public static void main(String[] args) {
		UserInterface nasaDB = new UserInterface();
		nasaDB.go();
	}
}
