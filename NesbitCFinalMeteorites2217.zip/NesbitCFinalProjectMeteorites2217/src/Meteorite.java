//CJ Nesbit
//NASA Meteorites Final

import java.io.Serializable;

public class Meteorite implements Serializable {
	private String name;
	private int id;
	private String nametype;
	private String recclass;
	private double mass; 
	private String fall; 
	private String year; 
	private double reclat;
	private double reclong;
	private Geolocation geolocation;

	public Meteorite() {
		this.name = "";
		this.id = 0; //id starts at 1
		this.nametype = "";
		this.recclass = "";
		this.mass = 0;
		this.fall = "";
		this.year = "";
		this.reclat = 0;
		this.reclong = 0;
		this.geolocation = new Geolocation();
	}
	
	
	public String display() { 
		return "name = " + this.name + ", id = " + Integer.toString(this.id) + ", recclass = " + this.recclass + ", mass = " + Double.toString(this.mass) + ", year = " + this.year;  
	}
	
	@Override
	public String toString() {
		return "Meteorite ["
				+ "name=" + this.getName()
				+ ", id=" + Integer.toString(this.getId())
				+ ", nametype=" + this.getNameType()
				+ ", recclass=" + this.getRecClass()
				+ ", mass=" + Double.toString(this.getMass())
				+ ", fall=" + this.getFall()
				+ ", year=" + this.getYear()
				+ ", reclat=" + this.getRecLat()
				+ ", reclong=" + this.getRecLong()
				+ ", geolocation=" + this.getLoc().toString()
				+ "]";
	}
	
	
	
//GETTERS AND SETTERS
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameType() {
		return nametype;
	}

	public void setNameType(String nameType) {
		this.nametype = nameType;
	}

	public String getRecClass() {
		return recclass;
	}

	public void setRecClass(String recClass) {
		this.recclass = recClass;
	}

	public double getMass() {
		return mass;
	}

	public void setMass(double mass) {
		this.mass = mass;
	}

	public String getFall() {
		return fall;
	}

	public void setFall(String fall) {
		this.fall = fall;
	}

	public String getYear() {
		if (this.year != null) {
			return this.year;
		} else {
			return "";
		}
	}
	
	public void setYear(String year) { 
		if (year.length() > 4 && year != null) {
			this.year = year.substring(0,4); //cuts off the real years
			return;
		}
		this.year = year; //sets null if the year isn't included, handled in the stream option 7
	}
	

	public double getRecLat() {
		return reclat;
	}

	public void setRecLat(double recLat) {
		this.reclat = recLat;
	}

	public double getRecLong() {
		return reclong;
	}

	public void setRecLong(double recLong) {
		this.reclong = recLong;
	}

	public Geolocation getLoc() {
		return geolocation;
	}

	public void setLoc(Geolocation loc) {
		this.geolocation = loc;
	}
}
