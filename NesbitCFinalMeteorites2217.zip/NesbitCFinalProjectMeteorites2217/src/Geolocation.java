//CJ Nesbit
//NASA Meteorites Final

import java.io.Serializable;

public class Geolocation implements Serializable {
	private double[] coordinates;
	private String type; 
	
	public Geolocation() {
		this.coordinates = new double[2];
		this.type = "Point";
	}
	
	//as far as I know these getters and setters aren't even used?
	//google search said that gson manually sets the fields without using setters
	//and the getters are never really used except for I guess the toString method but even thats unnecessary to use them
	public void setLocation(double x, double y) {
		this.coordinates[0] = x;
		this.coordinates[1] = y;
	}
	
	public double[] getLocation() {
		return this.coordinates;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getType() {
		return type;
	}
	
	@Override
	public String toString() {
		return "Geolocation ["
				+ "type=" + this.getType()
				+ ", coordinates=["
				+ this.getLocation()[0]
				+ ", " + this.getLocation()[1]
				+ "]]";
	}
}
