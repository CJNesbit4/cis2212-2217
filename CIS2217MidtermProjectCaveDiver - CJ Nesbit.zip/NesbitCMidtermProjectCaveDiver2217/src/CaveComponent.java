import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

import javax.swing.JComponent;

public class CaveComponent extends JComponent {
	private final int rows = 10;
	private final int cols = 10;
	private final Tile[][] tiles;
	
	/**
	 * creates a random board and calls the repaint method to immediately construct a board
	 */
	public CaveComponent() {
		//create random board
		tiles = new Tile[rows][cols];
		regen();
	}
	
	/**
	 * gives the 10x10 board of game tiles
	 * @return the tile array
	 */
	public Tile[][] getTiles() {
		return tiles;
	}
	
	/**
	 * highlights all tiles by calling the repaint method when ready
	 */
	public void highlightSolution() {
		repaint();
	}
	
	/**
	 * regenerates the board with random numbers and calls reset method
	 */
	public void regen() {
		Random randomEngine = new Random(); //random number generator
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				tiles[i][j] = new Tile(i,j,randomEngine.nextInt(10) + 1);
			}
		}
		reset();
	}
	
	/**
	 * sets all tiles to not be in the solution path and repaints them
	 */
	public void reset() {
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				tiles[i][j].setInPath(false);
			}
		}
		
		repaint();
	}
	
	/**
	 * calls each tile to dynamically repaint; all colors is handled by the tile internally
	 * @param g the graphics object
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				tiles[i][j].draw(g);
			}
		}
	}
}
