import java.awt.Color;
import java.awt.Graphics;

public class Tile {
	private int row;
	private int column;
	
	private int depth;
	private boolean isInPath;
	
	/**
	 * constructs a tile given the row, column, and depth
	 * @param row the tile's row
	 * @param column the tile's column
	 * @param depth the depth rating of the tile
	 */
	public Tile(int row, int column, int depth) {
		this.row = row;
		this.column = column;
		this.depth = depth;
		
		this.isInPath = false;
	}
	
	/**
	 * get the current tile row
	 * @return the tile row
	 */
	public int getRow() {
		return row;
	}

	/**
	 * get the current tile column
	 * @return the tile column
	 */
	public int getColumn() {
		return column;
	}

	/**
	 * get the depth rating
	 * @return the depth rating of the tile
	 */
	public int getDepth() {
		return depth;
	}

	/**
	 * checks if the current tile is in the solution path
	 * @return if the tile is in the solution path
	 */
	public boolean isInPath() {
		return isInPath;
	}
	
	/**
	 * sets if the current tile is in the solution path
	 * @param isInPath sets the current tile solution path boolean
	 */
	public void setInPath(boolean isInPath) {
		this.isInPath = isInPath;
	}

	/**
	 * draws the tile given the coordinates and shade
	 * @param g the graphics object
	 */
	public void draw(Graphics g) {
		int x = column * 50;
		int y = row * 50;
		
		if (isInPath) { //the tile is part of the solution path
			g.setColor(new Color(255, 0, 0, 200)); //paints the tile pure red
		} else { //the tile is not part of the solution path (default)
			int shade = 250 - depth * 20; //gradient of blue calculation
			g.setColor(new Color(20,30, shade)); //sets the color to the shade of blue: 20 and 30 are just random numbers I played around with that look nicer than pure blue
		}
		
		g.fillRect(x, y, 50, 50); //fills the rectangle with the current color and dimensions
		
		//sets a white border around every tile, not shown in instructions
		//looks nicer in my opinion so if you want just uncomment the below line to see
		//g.setcolor is required otherwise the number string blends in with the background
		g.setColor(Color.WHITE);
		//g.drawRect(x, y, 50, 50);
		
		String rating = String.valueOf(depth); //converts the depth to a string to display in the top left
		g.drawString(rating, x + 5, y + 15); //offsets the string number from the top left by a bit
	}
}
