//CJ Nesbit
//Cave Diver Midterm

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Viewer extends JFrame {
	public Viewer() {
		setLayout(new BorderLayout()); //border layout
		
		//layout in the north
		JLabel titleLabel = new JLabel("The diver begins in the upper-left corner and escapes by reaching the lower-right corner.", SwingConstants.CENTER);
		add(titleLabel, BorderLayout.NORTH);
		
		//cave board in the middle
		CaveComponent gameCave = new CaveComponent();
		gameCave.setPreferredSize(this.getSize());
		add(gameCave, BorderLayout.CENTER);
		
		//panel in the bottom
		DiverBottomPanel bottomPanel = new DiverBottomPanel(gameCave);
		add(bottomPanel, BorderLayout.SOUTH);
		
	}
	
	public static void main(String[] args) {
		JFrame frame = new Viewer(); //new frame construction
		frame.setTitle("Cave Diver"); //title
		
		//textbook stuff
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		frame.setSize(800,600);
		frame.setVisible(true);
	}
}
