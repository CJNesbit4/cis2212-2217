import java.util.Random;

public class Solver {
	private CaveComponent grid;
	private int rating;
	
	/**
	 * constructor that creates a grid solver object
	 * @param grid the CaveComponent grid to be solved
	 * @param rating the maximum rating that a solution tile can have
	 */
	public Solver(CaveComponent grid, int rating) {
		this.grid = grid;
		this.rating = rating;
	}
		
	/**
	 * Tells if the given grid is solvable : solvable cells are marked automatically
	 * @return true if the grid is solvable, false if not
	 */
	public boolean hasSolution() {
		return solve(grid.getTiles()[9][9]); //backwards so start from bottom right
	}
	
	/**
	 * 
	 * @param current the present tile to be checked
	 * @return true if the tile has relevant neighbors that can be traversed, false if tile is a dead end
	 */
	private boolean solve(Tile current) {
		if (current.getRow() == 0 && current.getColumn() == 0) { //YAY WE WIN!!! Base case #1
			current.setInPath(true);
			return true;
		}
		if (current.getDepth() > rating) { //Base Case #2. In reality the current cell can never be greater than the rating unless it is the first cell, so this prevents useless recursion if the exit cell is above the rating
			return false;
		}
		
		current.setInPath(true); //Temporarily marks the current cell as part of the solution
		//If it is actually not, backtracing will remove it at the bottom of the program
		
		//just me having fun by making the algorithm random
		//otherwise it always favors whatever direction you check first
		//this is objectively more fun and wasn't NOT allowed in the instructions
		Random randomEngine = new Random();
		int random = randomEngine.nextInt(2);
		
		if (random == 0) {
			if (canMoveLeft(current)) {
				if (solve(grid.getTiles()[current.getRow()][current.getColumn() - 1])) {
					return true;
				}
			}
			
			if (canMoveUp(current)) {
				if (solve(grid.getTiles()[current.getRow() - 1][current.getColumn()])) {
					return true;
				}
			}
			
		} else {
			
			if (canMoveUp(current)) {
				if (solve(grid.getTiles()[current.getRow() - 1][current.getColumn()])) {
					return true;
				}
			}
			if (canMoveLeft(current)) {
				if (solve(grid.getTiles()[current.getRow()][current.getColumn() - 1])) {
					return true;
				}
			}
			
		}
		
		//Cell is a dead end or is being backtracked
		
		//just disable the current cell as being part of the solution
		current.setInPath(false);
		
		//returning false is what causes backtracks
		return false;
	}
	
	
	/**
	 * checks if a tile's upward neighbor can be traversed 
	 * @param the current tile
	 * @return true if the tile matches or less than the diver rating, false if not
	 */
	private boolean canMoveUp(Tile tile) {
		if (tile.getRow() != 0) {
			return grid.getTiles()[tile.getRow() - 1][tile.getColumn()].getDepth() <= rating;
		} return false;
	}
	
	/**
	 * checks if a tile's leftward neighbor can be traversed
	 * @param the current tile
	 * @return true if the tile matches or less than the diver rating, false if not
	 */
	private boolean canMoveLeft(Tile tile) {
		if (tile.getColumn() != 0) {
			return grid.getTiles()[tile.getRow()][tile.getColumn() - 1].getDepth() <= rating;
		} return false;
	}
}
