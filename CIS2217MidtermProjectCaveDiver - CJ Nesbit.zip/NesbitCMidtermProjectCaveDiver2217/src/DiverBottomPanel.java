import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class DiverBottomPanel extends JPanel {
	private final CaveComponent grid;
	
	/**
	 * constructs the panel given the grid beforehand
	 * @param grid the game grid; needed to connect to button functionality
	 */
	public DiverBottomPanel(CaveComponent grid) {
		this.grid = grid;
		setLayout(new FlowLayout());
		
		JLabel depthRatingLabel = new JLabel("Enter the diver's depth rating: ");
		JTextField depthInputField = new JTextField(10);
		
		
		JButton escapeButton = new JButton("Escape");
		escapeButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				grid.reset();
				solveTest(depthInputField);
			}
		});
		
		JButton newButton = new JButton("New Cave");
		newButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				grid.regen();
			}
		});
		
		add(depthRatingLabel);
		add(depthInputField);
		add(escapeButton);
		add(newButton);
	}
	
	/**
	 * Calls the solver class with the given rating 
	 * @param field the user's diver rating
	 */
	private void solveTest(JTextField field) {
		try {
			int diverRating = Integer.parseInt(field.getText().trim());
			if (diverRating > 10 || diverRating < 0) {
				throw new IllegalArgumentException();
			}
			
			Solver solver = new Solver(grid, diverRating);
			if (solver.hasSolution()) {
				grid.highlightSolution();
			} else {
				JOptionPane.showMessageDialog(null, "No solution exists on the board."); //found from stackoverflow
			}
			//
		} catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(null, "Input a number for the diver rating."); //added after I put 5t as the diver rating
		} catch (IllegalArgumentException ex) {
			JOptionPane.showMessageDialog(null, "Enter a number 1-10");
		}
	}
	
	
}
