//CJ Nesbit
//Enhanced Binary Search Tree

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class UserInterface {
	public static void go(EnhancedBST bst) {
		int userSelect = -1; Scanner input = new Scanner(System.in);
		
		while (userSelect != 0) {
			System.out.println("Welcome to Enhanced BST Tester.");
			System.out.println("");
			System.out.println("Here is the menu of choices: ");
			System.out.println("    0) Quit");
			System.out.println("    1) Build BST from Text File");
			System.out.println("    2) Print the tree");
			System.out.println("    3) Add data");
			System.out.println("    4) Remove data");
			System.out.println("    5) Show tree height");
			System.out.println("    6) Show internal path length");
			System.out.println("    7) Show absent children");
			System.out.println("    8) Find a path sum");
			System.out.println("    9) Export BST to Text File");
			System.out.print("Enter your choice: ");
			
			try {
				userSelect = input.nextInt();
			} catch (InputMismatchException ex) {
				System.out.println("Error: Enter a valid integer for your selection.");
				userSelect = 0; //program terminates
			}
			
			switch (userSelect) {
			case 0: //DONE
				break;
			case 1: //DONE
				System.out.print("Enter the name of the file you wish to load from with the correct extension: ");
				String fileName = input.next();
				try {
					bst.load(fileName);
				} catch (FileNotFoundException ex) {
					System.out.println("Error: " + ex.getMessage());
				}
				break;
			case 2: //DONE
				bst.print();
				break;
			case 3: //DONE
				try {
					System.out.print("Enter the number you wish to add: ");
					int userInput = input.nextInt();
					
					bst.add(userInput);
				} catch (InputMismatchException ex) {
					System.out.println("Please enter an integer to add a value!");
				}
				break;
			case 4: //DONE
				try {
					System.out.print("Enter the number you wish to remove: ");
					int userInput = input.nextInt();
					
					bst.remove(userInput);
				} catch (InputMismatchException ex) {
					System.out.println("Please enter an integer to remove a value!");
				}
				break;
			case 5: //DONE
				System.out.println("The current height of the tree is " + bst.getHeight() + ".");
				break;
			case 6: //DONE
				System.out.println("The current internal path length of the tree is " + bst.getPathLength() + ".");
				break;
			case 7: //DONE
				System.out.println("The current amount of absent children in the tree is " + bst.getAbsent() + ".");
				break;
			case 8: //DONE
				System.out.print("Enter your requested path sum: ");
				int userSum = input.nextInt();
				if (bst.matchPathSum(userSum)) {
					System.out.println("There is currently a path sum with sum " + userSum + ".");
				} else {
					System.out.println("No path sum was found with sum " + userSum + ".");
				}
				break;
			case 9: //DONE
				System.out.print("Enter the name of the file you wish to save to with the correct extension: ");
				fileName = input.next();
				try {
					bst.save(fileName);
				} catch (FileNotFoundException ex) {
					System.out.println("Error: " + ex.getMessage());
				} catch (IOException ex) {
					System.out.println("Error: " + ex.getMessage());
				}
				break;
			default:
				break;
			}
		}
		input.close();
	}
	
	public static void main(String[] args) {
		EnhancedBST newTree = new EnhancedBST();
		go(newTree);
	}
}
