//CJ Nesbit
//Enhanced Binary Search Tree

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
import java.util.Stack;

public class EnhancedBST extends BinarySearchTree {
	
	public Iterator<Node> preorderIterator() {
		return new PreorderIterator(root);
	}
	
	private class PreorderIterator implements Iterator<Node> {
		private Stack<Node> stack;
		
		public PreorderIterator(Node root) {
			stack = new Stack<>();
			if (root != null) {
				stack.push(root);
			}
		}
		
		@Override
		public boolean hasNext() {
			//i have no idea if this works Eclipse just told me I had to override this abstract method
			return !stack.isEmpty();
		}

		@Override
		public BinarySearchTree.Node next() {
			Node currentNode = stack.pop();
			
			//right to left because stack and preorder traverse
			if (currentNode.right != null) {
				stack.push(currentNode.right);
			} 
			if (currentNode.left != null) {
				stack.push(currentNode.left);
			}
			
			return currentNode;
		}
		
	}
	
	public void print() {
		System.out.print("Inorder: ");
		print(root, 0);
		
		System.out.println(""); 
		System.out.print("Preorder: ");
		print(root, 1);
		
		System.out.println("");
		System.out.print("Postorder: ");
		print(root, 2);
		
		System.out.println("");
	}
	
	public static void print(Node parent, int mode) {
		switch(mode) {
		case 0: //inorder
			if (parent == null) { return; }
		        print(parent.left, mode);
		        System.out.print(parent.data + " ");
		        print(parent.right, mode);
		        break;
		case 1: //preorder
			if (parent == null) { return; }
				System.out.print(parent.data + " ");
		        print(parent.left, mode);
		        print(parent.right, mode);
		        break;
		case 2: //postorder
			if (parent == null) { return; }
	        print(parent.left, mode);
	        print(parent.right, mode);
			System.out.print(parent.data + " ");
	        break;
	    default:
	    	break;
		}
	}

	public void save(String fileName) throws FileNotFoundException, IOException { 
		File file = new File(fileName);
		try {
			if(!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException ex) {
					throw new IOException("Error creating file.");
				}
			}
			
			PrintWriter writer = new PrintWriter(file);
			
			Iterator<Node> iterator = preorderIterator();
			while (iterator.hasNext()) {
				Node node = iterator.next();
				if (node == null) {
					//should never get called because the iterator should skip nulls
					writer.println("/");
				} else {
					writer.println(node.data);
				}
			}
			
			writer.close();
		} catch (IOException ex) {
			throw new FileNotFoundException("The requested file cannot be found.");
		}
	}
	
	public void load(String fileName) throws FileNotFoundException {
		Queue<Integer> preorderRead = new LinkedList<>();
		File file = new File(fileName);

		if(!file.exists()) {
			throw new FileNotFoundException("The requested file cannot be found.");
		} else {
			try {
				Scanner scanner = new Scanner(file);
				
				while(scanner.hasNext()) {
					String temp = scanner.next();
					if (!temp.equals("/")) { //just in case the iterator screws up the save it ignores null nodes
						preorderRead.add(Integer.parseInt(temp));
					}
				} 
				scanner.close();
				
				while(!preorderRead.isEmpty()) {
					add(preorderRead.poll());
				}
				
			} catch (FileNotFoundException ex) {
				throw new FileNotFoundException("Scanner unable to retrieve file.");
			}
		}
	}
	
	public int getHeight() { 
		return getHeightHelper(root);
	}
	
	private int getHeightHelper(Node node) { 
		if (node == null) {
			return 0;
		}
		else {
			return 1 + Math.max(getHeightHelper(node.left), getHeightHelper(node.right));
			//copied straight from my CIS 2207 C++ binary tree implementation 
			//all the other helper methods are basically the same too
		}
	}
	
	public int getPathLength() {
		return getPathLengthHelper(root, 0);
	}
	
	private int getPathLengthHelper(Node node, int depth) {
		if (node == null) {
			return 0;
		}
		return depth + getPathLengthHelper(node.left, depth + 1) + getPathLengthHelper(node.right, depth + 1);
	}
	
	public int getAbsent() {
		return getAbsentHelper(root);
	}
	
	private int getAbsentHelper(Node node) {
		if (node == null) {
			return 0;
		}
		
		int absentCount = 0;
		if (node.left == null) {
			absentCount++;
		}
		if (node.right == null) {
			absentCount++;
		}	
		
		return absentCount + getAbsentHelper(node.left) + getAbsentHelper(node.right); 
	}
	
	public boolean matchPathSum(int userSum) {
		return matchPathSumHelper(root, userSum);
	}
	
	private boolean matchPathSumHelper(Node node, int adjustedSum) {
		if (node == null) {
			return false;
		}
		
		if (node.left == null && node.right == null) {
			//must be the end so the current node must equal whats left of the sum
			return ((Integer.compare(adjustedSum, (int) node.data)) == 0);
		}
		
		return matchPathSumHelper(node.left, adjustedSum - (int)node.data) || matchPathSumHelper(node.right, adjustedSum - (int)node.data);
	}
}


