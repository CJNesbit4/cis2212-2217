import java.util.Date;

public class Account {
	private int id;
	private double balance;
	private static double annualInterestRate;
	private Date dateCreated;
	
	Account() {
		this.id = 0;
		this.balance = 0;
		Account.annualInterestRate = 0;
		this.dateCreated = new Date(); //constructor found on StackOverflow (https://stackoverflow.com/questions/34119441/how-to-initialize-a-variable-of-date-type-in-java)
	}
	Account(int id, double balance) {
		this.id = id;
		this.balance = balance;
		Account.annualInterestRate = 0;
		this.dateCreated = new Date();
	}
	
	int getAccountID() {
		return id;
	}
	double getBalance() {
		return balance;
	}
	double getAnnualInterestRate() {
		return annualInterestRate;
	}
	Date getDateCreated() {
		return dateCreated;
	}
	
	void changeID(int id) {
		this.id = id;
		System.out.println("ID changed to " + id + ".");
		return;
	}
	void changeBalance(double balance) {
		this.balance = balance;
		System.out.println("Balance changed to $" + balance + ".");
		return;
	}
	void changeAnnualInterestRate(double annualInterestRate) {
		Account.annualInterestRate = annualInterestRate;
		System.out.println("Annual Interest Rate changed to " + annualInterestRate + "%.");
		return;
	}
	
	double getMonthlyInterestRate() {
		return (100 * (Math.pow((1 + (annualInterestRate / 100)), 0.0825) - 1));
	}
	void withdraw(double amount) {
		if (amount <= 0) {
			System.out.println("You cannot withdraw zero or negative amounts of money. Nice try!");
			return;
		}
		balance -= amount;
		System.out.println("Withdrawal successful. New balance: $" + balance);
		return;
	}
	void deposit(double amount) {
		if (amount <= 0) {
			System.out.println("You cannot deposit zero or negative amounts of money. Not sure why you would anyways...");
			return;
		}
		balance += amount;
		System.out.println("Deposit successful. New balance: $" + balance);
		return;
	}
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		Account myAccount = new Account(1122, 20000.0D);
		myAccount.changeAnnualInterestRate(4.5);
		
		myAccount.withdraw(2500);
		myAccount.deposit(3000);
		
		System.out.println("Balance in account is $" + myAccount.getBalance() + ".");
		System.out.println("Monthly Interest is " + myAccount.getMonthlyInterestRate() + "%.");
		System.out.println("Date Created (MM/DD/YYYY): " + (myAccount.getDateCreated().getMonth() + 1) + "/" + myAccount.getDateCreated().getDate() + "/" + (myAccount.getDateCreated().getYear() + 1900));
		
		return;
	}
}