import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;

public class InvestmentValue extends Application {

	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("Investment Value Calculator"); //Title
		
		FlowPane flowPane = new FlowPane();
		flowPane.setPadding(new Insets(10,10,10,10));
		flowPane.setHgap(10000);
		flowPane.setVgap(10);
		
		Label principalLabel = new Label("Investment Amount:");
		TextField principalInput = new TextField();
		principalInput.setPrefColumnCount(5);
		
		Label yearsLabel = new Label("Years:");
		TextField yearsInput = new TextField();
		yearsInput.setPrefColumnCount(5);
		
		Label interestRateLabel = new Label("Annual Interest Rate:");
		TextField interestRateInput = new TextField();
		interestRateInput.setPrefColumnCount(5);
		
		Label futureValueLabel = new Label("Future Value:");
		TextField futureValueResult = new TextField();
		futureValueResult.setPrefColumnCount(5);
		futureValueResult.setEditable(false);
		
		Button calculate = new Button("Calculate"); //calculate button
		calculate.setOnAction(e -> {
			try  {
				double investmentAmount = Double.parseDouble(principalInput.getText());
				double years = Double.parseDouble(yearsInput.getText());
				double monthlyInterestRate = (Double.parseDouble(interestRateInput.getText()) / 1200); //example in document gives rate as a percent, so I divide by 100, and then 12 for monthly
				double futureValue = investmentAmount * Math.pow(1 + monthlyInterestRate, 12 * years);
				futureValueResult.setText(String.format("%.2f", futureValue)); //Rounds to 2 decimal places like seen in document
			}
			catch (NumberFormatException ex) { //catches if the user inserts non-numbers or nothing as input
				System.out.println("Number formatting issue. This may be caused from invalid or null input.");
			}
		});
		
		 //flowPane method from Pearson, sorts from left to right, top to bottom
		flowPane.getChildren().addAll(principalLabel, principalInput, yearsLabel, yearsInput, interestRateLabel, interestRateInput, futureValueLabel, futureValueResult, calculate); 
		
		Scene scene = new Scene(flowPane, 400, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	
	
	
	public static void main(String[] args) {
		launch(args);
	}
}
