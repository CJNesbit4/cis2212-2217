import java.util.Scanner;

public class CreditCardValidation {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		long credCardNum = 0;
		System.out.print("Enter a credit card number: ");
		credCardNum = input.nextLong();
		
		if (isValid(credCardNum)) {
			System.out.println("Credit card number " + credCardNum + " is valid.");
		}
		else {
			System.out.println("Credit card number " + credCardNum + " is invalid.");
		}
		input.close();
		
	}
	
	public static boolean isValid(long number) {
		String tempString = Long.toString(number);
		if (tempString.length() < 13 || tempString.length() > 16) {
			System.out.println("Credit card number is invalid length");
			return false;
		}
		
		if (prefixMatched(number) && (((sumOfDoubleEvenPlace(number) + sumOfDoubleOddPlace(number)) % 10) == 0)) {
			return true;
		}

		return false;
	}
	public static int sumOfDoubleEvenPlace(long number) {
		int sum = 0;
		String tempString = Long.toString(number);
		
		for (int i = (tempString.length() - 2); i >= 0; i-=2) { 
			if (((int)(tempString.charAt(i) - '0') * 2) >= 10) {
				sum += ((((int)(tempString.charAt(i) - '0') * 2) / 10) + (((int)(tempString.charAt(i) - '0') * 2) - 10));
			}
			else {
				sum += ((int)(tempString.charAt(i) - '0') * 2);
			}
		}
		return sum;
	}
	public static int sumOfDoubleOddPlace(long number) {
		int sum = 0;
		String tempString = Long.toString(number);
		
		for (int i = (tempString.length() - 1); i >= 0; i-=2) {
			sum += (int)(tempString.charAt(i) - '0');
		}
		return sum;
	}
	public static boolean prefixMatched(long number) {
		String tempString = Long.toString(number);
		
		if (tempString.charAt(0) == '4' || tempString.charAt(0) == '5' || tempString.charAt(0) == '6' || (tempString.charAt(0) == '3' && tempString.charAt(1) == '7' )) {
			return true;
		}
		System.out.println("Credit card number begins with invalid digits");
		return false;
	}
	
}
