import java.util.Scanner;

public class PhoneKeypads {

	public static void main(String[] args) {
		char userLetter; //user char
		int number; //corresponding number
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter a letter: (A-Z): ");
		userLetter = input.nextLine().charAt(0);
		
		switch(userLetter) { //TO INSTRUCTOR: Please give feedback on this. I'm not sure if there is a more efficient way to do this. I tried coding something that used the ASCII values of the numbers, but couldn't come up with anything efficient. Thanks!
		 case 'A': case 'B': case 'C': 
             number = 2; 
             break;
         case 'D': case 'E': case 'F': 
             number = 3; 
             break;
         case 'G': case 'H': case 'I': 
             number = 4; 
             break;
         case 'J': case 'K': case 'L': 
             number = 5; 
             break;
         case 'M': case 'N': case 'O': 
             number = 6; 
             break;
         case 'P': case 'Q': case 'R': case 'S': 
             number = 7; 
             break;
         case 'T': case 'U': case 'V': 
             number = 8; 
             break;
         case 'W': case 'X': case 'Y': case 'Z': 
             number = 9; 
             break;
         default: //not valid input or maybe not a char
             number = -1; 
             break;
		}
		
		System.out.println("The corresponding digit is: " + number);
		System.out.println("In binary that is " + Integer.toBinaryString(number)); //also please give feedback on this. I couldn't find a way to convert to binary easily besides this method, but I also couldn't find this method in our textbook. So I am confused how I was supposed to obtain this.
		input.close();
	}

}
