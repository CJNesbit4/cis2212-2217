import java.util.Scanner;

public class ConsecutiveEqualNumbers {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int rows = 0; int columns = 0;
		
		System.out.print("Enter the amount of rows: ");
		rows = input.nextInt();
		System.out.print("Enter the amount of columns: ");
		columns = input.nextInt();
		
		if(rows < 4 || columns < 4) {
			System.out.println("To have a four in a row, you must have a board 4x4 or greater dimensions.");
			input.close();
			return;
		}
		
		int[][] array = new int[rows][columns];
		System.out.println("Enter the array numbers: ");
		for (int row = 0; row < array.length; row++) { //from section 8.3
			for (int column = 0; column < array[row].length; column++) {
				array[row][column] = input.nextInt();
			}
		}
		
		input.close();
		if(isConsecutiveFour(array)) {
			System.out.println("There was an instance of a four-in-a-row found");
			return;
		}
		else {
			System.out.println("There was no instance of a four-in-a-row found.");
			return;
		}
		
	}
	
	public static boolean isConsecutiveFour(int[][] array) {
		int rowLength = array.length; int columnLength = array[0].length;
		
		for (int i = 0; i < rowLength; i++) { //vertical 4 in a row
			for (int j = 0; j < columnLength; j++) {
				if (i + 3 >= rowLength) { break; }
				if (array[i][j] == array[i + 1][j] && array[i][j] == array[i + 2][j] && array[i][j] == array[i + 3][j]) {
					return true;
				}
			}
		}
		
		for (int i = 0; i <= rowLength; i++) { //horizontal checks
            for (int j = 0; j < columnLength; j++) {
            	if (i + 3 >= rowLength) { break; }
                if (array[i][j] == array[i + 1][j] && array[i][j] == array[i + 2][j] && array[i][j] == array[i + 3][j]) {
                    return true;
                }
            }
        }
		
		for (int i = 0; i <= rowLength; i++) { //diagonal backwards
            for (int j = 0; j <= columnLength; j++) {
            	if (i + 3 >= rowLength) { break; }
            	if (j + 3 >= columnLength) { break; }
                if (array[i][j] == array[i + 1][j + 1] && array[i][j] == array[i + 2][j + 2] && array[i][j] == array[i + 3][j + 3]) {
                    return true;
                }
            }
        }
		
		for (int i = 0; i <= rowLength; i++) { //diagonal forwards
			for (int j = columnLength - 1; j > 0; j--) {
				if (i + 3 >= rowLength) { break; }
				if (j - 3 < 0) { break; }
				if (array[i][j] == array[i + 1][j - 1] && array[i][j] == array[i + 2][j - 2] && array[i][j] == array[i + 3][j - 3]) {
					return true;
				}
			}
		}
		
		return false;
	}
}

