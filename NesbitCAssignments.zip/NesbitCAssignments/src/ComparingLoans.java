import java.util.Scanner;
public class ComparingLoans {

	public static void main(String[] args) {
		int loanAmount; int duration;
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the Loan Amount: ");
		loanAmount = input.nextInt();
		System.out.print("Enter the Number of Years: ");
		duration = input.nextInt();
		
		System.out.println("Interest Rate___Monthly Payment______Total Payment"); //3-6-split
		for (int i = 0; i < 25; i++) {
			double interestRate = ((((double)i) / 8) + 5.0);
			switch((i + 1) % 4) { //completely unnecessary but good for formatting
			case 0:
				System.out.print(interestRate + "%__");
				break;
			case 1:
				System.out.print(interestRate + "%____");
				break;
			case 2:
				System.out.print(interestRate + "%__");
				break;
			case 3:
				System.out.print(interestRate + "%___");
				break;
			default:
				System.out.println("logic error");
				break;
			}
			double monthlyPayment = loanAmount * (((interestRate / 1200) * (Math.pow((1 + (interestRate / 1200)), (12 * duration)))) / ((Math.pow((1 + (interestRate / 1200)), (12 * duration))) - 1));
			System.out.println(((double)(Math.round(monthlyPayment * 100)) / 100) + "______" + ((double)Math.round(monthlyPayment * 1200 * duration)) / 100);
			input.close();
		}
	}

}
