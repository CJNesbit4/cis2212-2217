import java.util.Scanner;

public class TaxComputation {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double sumTax = 0.0;
		
		System.out.print("Enter your filing status (0 for single, 1 for Married Jointly or Qualified Widow, 2 for Married filing seperately, 3 for Head of Household):");
		int filingStatus = input.nextInt();
		
		System.out.print("Enter your taxable income: ");
		int taxableIncome = input.nextInt();
		
		switch (filingStatus) {
		case 0:
			if (taxableIncome <= 8350) {
				sumTax += (taxableIncome * 0.1);
				break;
			}
			if (taxableIncome <= 33950) {
				sumTax += (8350 * 0.1); //shown in full form instead of result for clarity/ease of grading
				sumTax += ((taxableIncome - 8350) * 0.15);
				break;
			}
			if (taxableIncome <= 82250) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((taxableIncome - 33950) * 0.25);
				break;
			}
			if (taxableIncome <= 171550) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((82250 - 33950) * 0.25);
				sumTax += ((taxableIncome - 82250) * 0.28);
				break;
			}
			if (taxableIncome <= 372950) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((82250 - 33950) * 0.25);
				sumTax += ((171550 - 82250) * 0.28);
				sumTax += ((taxableIncome - 171550) * 0.33);
				break;
			}
			else {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((82250 - 33950) * 0.25);
				sumTax += ((171550 - 82250) * 0.28);
				sumTax += ((372950 - 171550) * 0.33);
				sumTax += ((taxableIncome - 372950) * 0.35);
				break;
			}
		case 1:
			if (taxableIncome <= 16700) {
				sumTax += (taxableIncome * 0.1);
				break;
			}
			if (taxableIncome <= 67900) {
				sumTax += (16700 * 0.1);
				sumTax += ((taxableIncome - 16700) * 0.15);
				break;
			}
			if (taxableIncome <= 137050) {
				sumTax += (16700 * 0.1);
				sumTax += ((67900 - 16700) * 0.15);
				sumTax += ((taxableIncome - 67900) * 0.25);
				break;
			}
			if (taxableIncome <= 208850) {
				sumTax += (16700 * 0.1);
				sumTax += ((67900 - 16700) * 0.15);
				sumTax += ((137050 - 67900) * 0.25);
				sumTax += ((taxableIncome - 137050) * 0.28);
				break;
			}
			if (taxableIncome <= 372950) {
				sumTax += (16700 * 0.1);
				sumTax += ((67900 - 16700) * 0.15);
				sumTax += ((137050 - 67900) * 0.25);
				sumTax += ((208850 - 137050) * 0.28);
				sumTax += ((taxableIncome - 208850) * 0.33);
				break;
			}
			else {
				sumTax += (16700 * 0.1);
				sumTax += ((67900 - 16700) * 0.15);
				sumTax += ((137050 - 67900) * 0.25);
				sumTax += ((208850 - 137050) * 0.28);
				sumTax += ((372950 - 208850) * 0.33);
				sumTax += ((taxableIncome - 372950) * 0.35);
				break;
			}
		case 2:
			if (taxableIncome <= 8350) {
				sumTax += (taxableIncome * 0.1);
				break;
			}
			if (taxableIncome <= 33950) {
				sumTax += (8350 * 0.1);
				sumTax += ((taxableIncome - 8350) * 0.15);
				break;
			}
			if (taxableIncome <= 68525) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((taxableIncome - 33950) * 0.25);
				break;
			}
			if (taxableIncome <= 104425) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((68525 - 33950) * 0.25);
				sumTax += ((taxableIncome - 68525) * 0.28);
				break;
			}
			if (taxableIncome <= 186475) {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((68525 - 33950) * 0.25);
				sumTax += ((104425 - 68525) * 0.28);
				sumTax += ((taxableIncome - 104425) * 0.33);
				break;
			}
			else {
				sumTax += (8350 * 0.1);
				sumTax += ((33950 - 8350) * 0.15);
				sumTax += ((68525 - 33950) * 0.25);
				sumTax += ((104425 - 68525) * 0.28);
				sumTax += ((186475 - 104425) * 0.33);
				sumTax += ((taxableIncome - 186475) * 0.35);
				break;
			}
		case 3:
			if (taxableIncome <= 11950) {
				sumTax += (taxableIncome * 0.1);
				break;
			}
			if (taxableIncome <= 45500) {
				sumTax += (11950 * 0.1);
				sumTax += ((taxableIncome - 11950) * 0.15);
				break;
			}
			if (taxableIncome <= 117450) {
				sumTax += (11950 * 0.1);
				sumTax += ((45500 - 11950) * 0.15);
				sumTax += ((taxableIncome - 45500) * 0.25);
				break;
			}
			if (taxableIncome <= 190200) {
				sumTax += (11950 * 0.1);
				sumTax += ((45500 - 11950) * 0.15);
				sumTax += ((117450 - 45500) * 0.25);
				sumTax += ((taxableIncome - 117450) * 0.28);
				break;
			}
			if (taxableIncome <= 372950) {
				sumTax += (11950 * 0.1);
				sumTax += ((45500 - 11950) * 0.15);
				sumTax += ((117450 - 45500) * 0.25);
				sumTax += ((190200 - 117450) * 0.28);
				sumTax += ((taxableIncome - 190200) * 0.33);
				break;
			}
			else {
				sumTax += (11950 * 0.1);
				sumTax += ((45500 - 11950) * 0.15);
				sumTax += ((117450 - 45500) * 0.25);
				sumTax += ((190200 - 117450) * 0.28);
				sumTax += ((372950 - 190200) * 0.33);
				sumTax += ((taxableIncome - 372950) * 0.35);
				break;
			}
		default:
			System.out.println("You entered an invalid filing status. Please restart the program and enter 0-3 instead.");
			break;
		}
		System.out.println("Your tax due is $" + sumTax);
		input.close();
	}
}
