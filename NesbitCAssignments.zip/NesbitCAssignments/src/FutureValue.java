import java.util.Scanner;

public class FutureValue {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter investment amount:");
		int investmentAmount = input.nextInt();
		
		System.out.print("Enter annual interest rate:");
		double interestRate = input.nextDouble();
		
		System.out.print("Enter number of years:");
		int numYears = input.nextInt();
		
		double accumulatedValue = investmentAmount * Math.pow((1 + (interestRate / 1200)), (numYears * 12));
		System.out.println("Accumulated value is: " + accumulatedValue);
		
		input.close();
	}

}
