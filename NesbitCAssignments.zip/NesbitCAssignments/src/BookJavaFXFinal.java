import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class BookJavaFXFinal extends Application {
	private String title;
	private String author;
	public boolean available;
	public Date dateLoaned;
	
	public int timesLoaned;
	public Date dateCreated;
	
	private static ArrayList<BookJavaFXFinal> library = new ArrayList<>(); //static arrayList
	private static final String FILE_SAVE = "autosave.txt";
	private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm"); //Date format for save file
	
	public BookJavaFXFinal() {
		this.title = "";
		this.author = "";
		this.available = false; //false because no data
		this.dateLoaned = null; 
		this.timesLoaned = 0;
		this.dateCreated = new Date();
	}
	public BookJavaFXFinal(String title, String author) { 
		//Disallows the user to enter books with no name or author, as well as disallowing the parsing character for the save file
		if (title == null || title.isBlank() || title.isEmpty() || title.contains("|")) {
			throw new IllegalArgumentException("Title is null, empty, or contains illegal characters.");
		}
		if (author == null || author.isBlank() || author.isEmpty() || author.contains("|")) {
			throw new IllegalArgumentException("Author is null, empty, or contains illegal characters.");
		}
		this.title = title;
		this.author = author;
		available = true; //true if created
		this.dateLoaned = null;
		timesLoaned = 0;
		dateCreated = new Date();
	}
	
	//ACCESSORS
	String getTitle() {
		return this.title;
	}
	String getAuthor() {
		return this.author;
	}
	boolean isAvailable() {
		return this.available;
	}
	Date getDateLoaned() {
		return this.dateLoaned;
	}
	int getTimesLoaned() {
		return this.timesLoaned;
	}
	Date getDateCreated() {
		return this.dateCreated;
	}
	
	//MUTATORS
	private void changeTitle(String title) {
		this.title = title;
		return;
	}
	private void changeAuthor(String author) {
		this.author = author;
		return;
	}
	private void changeAvailability(boolean bool) {
		this.available = bool ? true : false;
	}
	private void changeDateLoaned(Date date) {
		this.dateLoaned = date;
	}
	private void intentionallySetDateNull() { //very niche but prevents a NullPointerException on the previous method. See file management comments for more info
		this.dateLoaned = null;
	}
	private void changeDateCreated(Date date) {
		this.dateCreated = date;
	}
	
	void checkOut() {
		this.timesLoaned++;
		this.available = false;
		this.dateLoaned = new Date();
		return;
	}
	void bookReturn() {
		this.available = true;
		return;
	}
	
	private Button createBackButton(Stage stage, Scene mainScene) { //Creates back button for each scene
		Button backButton = new Button("Back");
		backButton.setOnAction(e -> {
			stage.setScene(mainScene); //passed the main scene to switch to
		});
		return backButton;
	}
	
	private Label createBottomText() { //Creates feedback text for each scene
		Label bottomText = new Label("");
		bottomText.setStyle("-fx-text-fill: red"); //CSS styling that sets text color to red
		return bottomText;
	}
	
	//Add book scene
	private Scene createAddBookScene(Stage primaryStage, Scene mainScene) { 
		VBox addBookPane = new VBox();
		addBookPane.setPadding(new Insets(10,10,10,10));
		addBookPane.setSpacing(10);
		Button addBookTextButton = new Button("Add Book");
		Label addBookTitle = new Label("Book Title:");
		TextField addBookTitleField = new TextField();
		Label addBookAuthor = new Label("Book Author:");
		TextField addBookAuthorField = new TextField();
		Button tenDefaultBooks = new Button("Add ten default books");
		
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();

		addBookPane.getChildren().addAll(addBookTitle, addBookTitleField, addBookAuthor, addBookAuthorField, addBookTextButton, tenDefaultBooks, backButton, bottomText);
	
		addBookTextButton.setOnAction(e -> {
			try {
				BookJavaFXFinal userBook = new BookJavaFXFinal(addBookTitleField.getText(), addBookAuthorField.getText());
				library.add(userBook);
				bottomText.setText("Successfully added book.");
			} catch (IllegalArgumentException ex) {
				bottomText.setText(ex.getMessage()); 
			}
		});
		//Ten default books
		tenDefaultBooks.setOnAction(e -> {
			library.add(new BookJavaFXFinal("Huckleberry Finn","Mark Twain"));
			library.add(new BookJavaFXFinal("How the Grinch Stole Christmas","Dr. Seuss"));
			library.add(new BookJavaFXFinal("Old Yeller","Fred Gipson"));
			library.add(new BookJavaFXFinal("How to Win at Chess","Levy Rozman"));
			library.add(new BookJavaFXFinal("Java: A Beginner's Guide","Herbert Schilt"));
			library.add(new BookJavaFXFinal("Western Civilizations","Joshua Cole, Carol Symes"));
			library.add(new BookJavaFXFinal("The Decline and Fall of the Roman Empire","Edward Gibbon"));
			library.add(new BookJavaFXFinal("The Wizard of Oz","Frank Baum"));
			library.add(new BookJavaFXFinal("The Hobbit","J. R. R. Tolkien"));
			library.add(new BookJavaFXFinal("The Yellow House Mystery","Gertrude Warner"));
			bottomText.setText("Successfully added ten default books.");
		});
		return new Scene(addBookPane, 400, 400);
	}
	
	//Remove book scene
	private Scene createRemoveBookScene(Stage primaryStage, Scene mainScene) {
		VBox removeBookPane = new VBox();
		removeBookPane.setPadding(new Insets(10,10,10,10));
		removeBookPane.setSpacing(10);
		Label removeBookInfo = new Label("Remove Book by index. If you do not know the index, use the search function instead.");
		TextField removeBookIndex = new TextField();
		Button removeBookButton = new Button("Remove Book");
		
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();
		removeBookButton.setOnAction(e -> {
			try {
				int index = Integer.parseInt(removeBookIndex.getText()); //Checks to see if textfield contains an integer
				if (index >= library.size()) {
					bottomText.setText("Index is larger than the size of the library.");
				}
				else {
					library.remove(index);
					bottomText.setText("Successfully removed.");
				}
			}
			catch (NumberFormatException ex) { //Not a number
				bottomText.setText("Information provided is not an index number.");
			}
			catch (IndexOutOfBoundsException ex) { //negative number 
				bottomText.setText("Requested index cannot be negative.");
			}
		});
		removeBookPane.getChildren().addAll(removeBookInfo, removeBookIndex, removeBookButton, backButton, bottomText);
		return new Scene(removeBookPane, 400, 400);
	}
	
	//Create Book list scene
	private Scene createListBooksScene(Stage primaryStage, Scene mainScene) {
		VBox bookListPane = new VBox();
		bookListPane.setPadding(new Insets(10,10,10,10));
		bookListPane.setSpacing(10);
		Label bookListLabel = new Label("Pulau Jawa Library Inventory:");
		TextArea bookListText = new TextArea();
		bookListText.setEditable(false); //user cannot edit the text
		String bookListString = "";
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();
		
		//Fills string with book details. Separates each book using \n newline character
		for (int i = 0; i < library.size(); i++) {
			bookListString += (i + ". " + library.get(i).getTitle() + " by " + library.get(i).getAuthor());
			if (library.get(i).isAvailable()) {
				bookListString += ". Available.\n";
			}
			else {
				bookListString += (". Not available, last checked out " + formatDate(library.get(i).getDateLoaned()) + " at " + formatTime(library.get(i).getDateLoaned()) + ".\n");
			}
		}
		ScrollPane bookListScrollPane = new ScrollPane();
		bookListText.setText(bookListString);
		bookListScrollPane.setContent(bookListText);
		bookListPane.getChildren().addAll(bookListLabel, bookListScrollPane, backButton, bottomText);
		return new Scene(bookListPane, 400, 400);
	}
	
	//Create search scene
	private Scene createSearchScene(Stage primaryStage, Scene mainScene) {
		VBox searchBookPane = new VBox();
		searchBookPane.setPadding(new Insets(10,10,10,10));
		searchBookPane.setSpacing(10);
		Label searchLabel = new Label("Enter Search (Title or Author)");
		TextField searchCriteria = new TextField();
		Button searchButton = new Button("Search");
		Label searchResultsLabel = new Label("Search Results");
		TextArea searchResultsArea = new TextArea();
		searchResultsArea.setEditable(false); //user cannot edit search results
		searchResultsArea.setPrefSize(300,200);
		ScrollPane searchResultsScrollPane = new ScrollPane();
		searchResultsScrollPane.setContent(searchResultsArea);
		searchResultsScrollPane.setFitToWidth(true);
		searchResultsScrollPane.setFitToHeight(true);
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();
		
		searchButton.setOnAction(e -> {
			try {
				String str = searchCriteria.getText();
				if (str.isBlank() || str.isEmpty() || str.equalsIgnoreCase("")) { //Search string is empty
					throw new IllegalArgumentException("Empty String");
				}
				//title has search priority
				if (searchTitle(library, str) != -1) {
					int index = searchTitle(library, str);
					String searchString = ""; //Same newline strategy as book list method
					searchString += ("Search Result for " + str + ":\nTitle: " + library.get(index).getTitle() + ".\nAuthor: " + library.get(index).getAuthor() + ".\nAvailability: ");
					if (library.get(index).isAvailable()) {
						searchString += "Book is available.\n";
					}
					else {
						searchString += ("Book is unavailable. Last checked out on " + formatDate(library.get(index).getDateLoaned()) + " at " + formatTime(library.get(index).getDateLoaned()) + ".\n");
					}
					
					searchString += ("Times Loaned: " + library.get(index).getTimesLoaned() + ".\nDate arrived at library: " + formatDate(library.get(index).getDateCreated()) + " at " + formatTime(library.get(index).getDateCreated()) + ".\nIndex Number: " + index + ".");
					searchResultsArea.setText(searchString);
				}
				else if (searchAuthor(library, str) != -1) {
					int index = searchAuthor(library, str);
					String searchString = "";
					searchString += ("Search Result for " + str + ":\nTitle: " + library.get(index).getTitle() + ".\nAuthor: " + library.get(index).getAuthor() + ".\nAvailability: ");
					if (library.get(index).isAvailable()) {
						searchString += "Book is available.\n";
					}
					else {
						searchString += ("Book is unavailable. Last checked out on " + formatDate(library.get(index).getDateLoaned()) + " at " + formatTime(library.get(index).getDateLoaned()) + ".\n");
					}
					
					searchString += ("Times Loaned: " + library.get(index).getTimesLoaned() + ".\nDate arrived at library: " + formatDate(library.get(index).getDateCreated()) + " at " + formatTime(library.get(index).getDateCreated()) + ".\nIndex Number: " + index + ".");
					searchResultsArea.setText(searchString);
				}
				else { //no result found
					searchResultsArea.setText("No search results found for " + str + ".");
				}
			} catch (IllegalArgumentException ex) { //catches empty string exception from above
				bottomText.setText("Search field is empty");
			}
		});
		searchBookPane.getChildren().addAll(searchLabel, searchCriteria, searchButton, searchResultsLabel, searchResultsScrollPane, backButton, bottomText);
		return new Scene(searchBookPane, 400, 400);
	}
	
	//Create checkout scene
	private Scene createCheckOutScene(Stage primaryStage, Scene mainScene) {
		VBox checkOutBookPane = new VBox();
		checkOutBookPane.setPadding(new Insets(10,10,10,10));
		checkOutBookPane.setSpacing(10);
		Label checkOutLabel = new Label("Check out by Title or Index:");
		TextField checkOutCriteria = new TextField();
		Button checkOutButton = new Button("Check Out");
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();
		checkOutButton.setOnAction(e -> {
			try {
				int index = Integer.parseInt(checkOutCriteria.getText()); //Check to see if user entered an index number
				if (index >= library.size()) {
					bottomText.setText("The library does not contain a book with index " + index + ".");
				} 
				else {
					if (library.get(index).isAvailable()) { //Checks if book is available to be checked out
						library.get(index).checkOut();
						bottomText.setText(library.get(index).getTitle() + " by " + library.get(index).getAuthor() + " successfully checked out.");
					}
					else {
						bottomText.setText("Your requested book is not available.");
					}
				}
			}
			catch (NumberFormatException ex) { //is a title 
				String str = checkOutCriteria.getText();
				if (str.isEmpty() || str.isBlank()) {
					bottomText.setText("Book title is empty.");
				}
				else {
					int index = searchTitle(library, str);
					if (index == -1) {
						bottomText.setText("No book with title " + str + " was found.");
					}
					else {
						if (library.get(index).isAvailable()) {
							library.get(index).checkOut();
							bottomText.setText(library.get(index).getTitle() + " by " + library.get(index).getAuthor() + " successfully checked out.");
						}
						else {
							bottomText.setText("Your requested book is not available.");
						}
					}
				}
			}
			catch (IndexOutOfBoundsException ex) { //negative number 
				bottomText.setText("Requested index cannot be negative.");
			}
		});
		checkOutBookPane.getChildren().addAll(checkOutLabel, checkOutCriteria, checkOutButton, backButton, bottomText);
		return new Scene(checkOutBookPane, 400, 400);
	}
	
	//Create return scene
	private Scene createReturnScene(Stage primaryStage, Scene mainScene) {
		VBox returnBookPane = new VBox();
		returnBookPane.setPadding(new Insets(10,10,10,10));
		returnBookPane.setSpacing(10);
		Label returnBookLabel = new Label("Return book by Title or Index:");
		TextField returnBookCriteria = new TextField();
		Button returnBookButton = new Button("Return book");
		Button backButton = createBackButton(primaryStage, mainScene);
		Label bottomText = createBottomText();
		returnBookButton.setOnAction(e -> {
			try {
				int index = Integer.parseInt(returnBookCriteria.getText()); //checks for index
				if (index >= library.size()) {
					bottomText.setText("The library does not contain a book with index " + index + ".");
				}
				else {
					if (!library.get(index).isAvailable()) { //if it is NOT available, it can be returned
						library.get(index).bookReturn();
						bottomText.setText(library.get(index).getTitle() + " by " + library.get(index).getAuthor() + " successfully returned.");
					}
					else {
						bottomText.setText("Your requested book has not been checked out.");
					}
				}
			} catch (NumberFormatException ex) { //is a title 
				String str = returnBookCriteria.getText();
				if (str.isEmpty() || str.isBlank()) {
					bottomText.setText("Book title is empty.");
				}
				else {
					int index = searchTitle(library, str);
					if (index == -1) {
						bottomText.setText("No book with title " + str + " was found.");
					}
					else {
						if (!library.get(index).isAvailable()) {
							library.get(index).bookReturn();
							bottomText.setText(library.get(index).getTitle() + " by " + library.get(index).getAuthor() + " successfully returned.");
						}
						else {
							bottomText.setText("Your requested book has not been checked out.");
						}
					}
				}
			}
			catch (IndexOutOfBoundsException ex) { //negative number 
				bottomText.setText("Requested index cannot be negative.");
			}
		});
		returnBookPane.getChildren().addAll(returnBookLabel, returnBookCriteria, returnBookButton, backButton, bottomText);
		return new Scene(returnBookPane, 400, 400);
	}
	
	//Create view book details from index scene
	private Scene createViewBookScene(Stage primaryStage, Scene mainScene) {
		VBox viewBookPane = new VBox();
		viewBookPane.setPadding(new Insets(10,10,10,10));
		viewBookPane.setSpacing(10);
		TextArea viewBookTextArea = new TextArea();
		viewBookTextArea.setEditable(false); //results is not editable by user
		Label viewBookLabel = new Label("View Book Details by Index");
		TextField viewBookCriteria = new TextField();
		Button viewBookDetails = new Button("View Details");
		Button backButton = createBackButton(primaryStage, mainScene);
        Label bottomText = createBottomText();
		viewBookDetails.setOnAction(e -> {
			try {
				int index = Integer.parseInt(viewBookCriteria.getText());
				if (index >= library.size()) {
					bottomText.setText("The library does not contain a book with index " + index + ".");
				} 
				else { //creates string to be displayed
					String fullString = "";
					fullString += ("Title: " + library.get(index).getTitle() + ".\nAuthor: " + library.get(index).getAuthor() + ".\nAvailability: ");
					if (library.get(index).isAvailable()) {
						fullString += "Book is available.\n";
					}
					else {
						fullString += ("Book is unavailable. Last checked out on " + formatDate(library.get(index).getDateLoaned()) + " at " + formatTime(library.get(index).getDateLoaned()) + ".\n");
					}
					
					fullString += ("Times Loaned: " + library.get(index).getTimesLoaned() + ".\nDate arrived at library: " + formatDate(library.get(index).getDateCreated()) + " at " + formatTime(library.get(index).getDateCreated()) + ".");
					viewBookTextArea.setText(fullString);
				}
			} catch (NumberFormatException ex) {
				bottomText.setText("The search criteria must be a number, the index of the book. To find the index of the book, use the search function instead.");
			} catch (IndexOutOfBoundsException ex) { //negative number 
				bottomText.setText("Requested index cannot be negative.");
			}
		});
		ScrollPane viewBookScrollPane = new ScrollPane();
		viewBookScrollPane.setContent(viewBookTextArea);
		viewBookPane.getChildren().addAll(viewBookLabel, viewBookCriteria, viewBookDetails, viewBookScrollPane, backButton, bottomText);
		return new Scene(viewBookPane, 400, 400);
	}
	/*//OLD FILE MANAGEMENT SCENE AND CODE
	private Scene createFileManagementScene(Stage primaryStage, Scene mainScene) {
		VBox fileFlowPane = new VBox();
		fileFlowPane.setPadding(new Insets(10,10,10,10));
		fileFlowPane.setSpacing(10);
		Label fileManagementLabel = new Label("Enter File Name here (.txt format only):");
		TextField fileName = new TextField();
		Button importButton = new Button("Import");
		Button exportButton = new Button("Export");
		Button backButton = createBackButton(primaryStage, mainScene);
        Label bottomText = createBottomText();
		fileFlowPane.getChildren().addAll(fileManagementLabel, fileName, importButton, exportButton, backButton, bottomText);
		importButton.setOnAction(e -> {
			try {
				Scanner input = new Scanner(new File(fileName.getText()));
				library.clear();
				
				while (input.hasNext()) {
					BookJavaFXFinal book = new BookJavaFXFinal();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm"); //date format found from stackoverflow
					String line = input.nextLine();
					String[] parts = line.split("\\|"); //parsing solution stackoverflow
					
					book.changeTitle(parts[1]);
					book.changeAuthor(parts[2]);
					book.changeAvailability(Boolean.parseBoolean(parts[3]));
					if ("null".equals(parts[4])) {
						book.intentionallySetDateNull();
					} else {
						book.changeDateLoaned(sdf.parse(parts[4]));
					}
					book.changeDateCreated(sdf.parse(parts[5]));
					
					library.add(book);
				}
				input.close();
				bottomText.setText("Import finished.");
			} catch (FileNotFoundException ex) {
				bottomText.setText("System could not find the file specified.");
			} catch (ParseException ex) {
				bottomText.setText("Parsing date exception on import.");
			} catch (ArrayIndexOutOfBoundsException ex) {
				bottomText.setText("Error: Not enough elements found to import.");
			}
		});
		exportButton.setOnAction(e -> {
			java.io.File file = new java.io.File(fileName.getText());
			try {
				java.io.PrintWriter output = new java.io.PrintWriter(file);
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm"); //date format found from stackoverflow
				for (int i = 0; i < library.size(); i++) {
					output.print(i + "|" + library.get(i).getTitle() + "|" + library.get(i).getAuthor() + "|" + library.get(i).isAvailable() + "|");
					if (library.get(i).getDateLoaned() == null) {
						output.print("null|");
					} else {
						output.print(sdf.format(library.get(i).getDateLoaned() + "|"));
					}
					output.println(sdf.format(library.get(i).getDateCreated()));
				}
				output.close();
				bottomText.setText("Export finished.");
			} catch (FileNotFoundException ex) {
				bottomText.setText("System could not find the file specified.");
			}	
		});
		return new Scene(fileFlowPane, 400, 400);
	}
	*/
	
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("Palau Jawa Library");
				
		VBox menuPane = new VBox();
		menuPane.setPadding(new Insets(10,10,10,10));
		menuPane.setSpacing(10);
		
		Label titleLabel = new Label("Pulau Jawa Library Main Menu");
		Button addBook = new Button("Add Book");
		Button removeBook = new Button("Remove Book");
		Button listBooks = new Button("List all books and availability");
		Button search = new Button("Search");
		Button checkOut = new Button("Check out a book");
		Button returnBook = new Button("Return a book");
		Button viewBook = new Button("View book details from index");
		//Button fileManagement = new Button("Import/Export Library"); //Old file management button
		Button quit = new Button("Save and Quit");
		Label bottomText = createBottomText();

		menuPane.getChildren().addAll(titleLabel, addBook, removeBook, listBooks, search, checkOut, returnBook, viewBook, quit, bottomText);
		Scene mainScene = new Scene(menuPane, 400, 400);
		
		try {
			initializeLibrary();
			bottomText.setText("Successfully imported library.");
		} catch (FileNotFoundException ex) {
			bottomText.setText(ex.getMessage());
		} catch (IOException ex) {
			bottomText.setText(ex.getMessage());
		} catch (ParseException ex) {
			bottomText.setText(ex.getMessage() + " Error at index " + ex.getErrorOffset() + ".");
		} catch (ArrayIndexOutOfBoundsException ex) {
			bottomText.setText(ex.getMessage());
		}

		addBook.setOnAction(e -> {
			primaryStage.setScene(createAddBookScene(primaryStage, mainScene));
		});
		removeBook.setOnAction(e -> {
			primaryStage.setScene(createRemoveBookScene(primaryStage, mainScene));
		});
		listBooks.setOnAction(e -> {
			primaryStage.setScene(createListBooksScene(primaryStage, mainScene));
		});
		search.setOnAction(e -> {
			primaryStage.setScene(createSearchScene(primaryStage, mainScene));
		});
		checkOut.setOnAction(e -> {
			primaryStage.setScene(createCheckOutScene(primaryStage, mainScene));
		});
		returnBook.setOnAction(e -> {
			primaryStage.setScene(createReturnScene(primaryStage, mainScene));
		});
		viewBook.setOnAction(e -> {
			primaryStage.setScene(createViewBookScene(primaryStage, mainScene));
		});
		/*
		fileManagement.setOnAction(e -> {
			primaryStage.setScene(createFileManagementScene(primaryStage, mainScene));
		});
		*/
		quit.setOnAction(e -> {
			try {
				saveLibrary();
			} catch (FileNotFoundException ex) {
				bottomText.setText(ex.getMessage() + " This means the file was deleted during the runtime of the program or was corrupted on creation.");
			}
			Platform.exit();
		});
		primaryStage.setScene(mainScene);
		primaryStage.show();
		
		
	}
	
	@Override
	public void stop() { //saves library if program is closed without quit button
		try {
			saveLibrary();
		} catch (FileNotFoundException ex) {} //Would like feedback on how to handle the exception if program is closing? 
	}

	public static void main(String[] args) {
		launch(args);
	}
	
	public static int searchTitle(ArrayList<BookJavaFXFinal> library, String str) { //search by title, ignores case
		for (int i = 0; i < library.size(); i++) {
			if (library.get(i).getTitle().equalsIgnoreCase(str)) {
				return i;
			}
		}
		
		return -1;
	}
	
	public static int searchAuthor(ArrayList<BookJavaFXFinal> library, String str) { //search by author, ignores case
		for (int i = 0; i < library.size(); i++) {
			if (library.get(i).getAuthor().equalsIgnoreCase(str)) {
				return i;
			}
		}
		
		return -1;
	}
	
	public static void initializeLibrary() throws IOException, ParseException { //Imports save file
		File file = new File(FILE_SAVE);
		if (!file.exists()) { //If file does not exist already (library started for first time)
			try {
                file.createNewFile();
            } catch (IOException ex) {
            	throw new IOException("Error creating autosave file.");
            }
		} else { //file exists
			try (Scanner scanner = new Scanner(file)) {
				while (scanner.hasNext()) {
					String line = scanner.nextLine(); //read by line, program is saved line by line per book
					if (!line.isEmpty()) {
						BookJavaFXFinal book = new BookJavaFXFinal();
						String[] parts = line.split("\\|"); //parsing solution stackoverflow
						
						book.changeTitle(parts[1]);
						book.changeAuthor(parts[2]);
						book.changeAvailability(Boolean.parseBoolean(parts[3]));
						if ("null".equals(parts[4])) {
							book.intentionallySetDateNull();
						} else {
							book.changeDateLoaned(sdf.parse(parts[4]));
						}
						book.changeDateCreated(sdf.parse(parts[5]));
						
						library.add(book);
					} //no need for else statement because if save is empty, library will already be empty
				}
			} catch (FileNotFoundException ex) {
				throw new FileNotFoundException("Error accessing save file.");
			} catch (ParseException ex) {
				throw new ParseException("Parsing error on import.", ex.getErrorOffset());
			} catch (ArrayIndexOutOfBoundsException ex) {
				throw new ArrayIndexOutOfBoundsException("Autosave file is corrupted, import failed.");
			}
		}
	}

	public static void saveLibrary() throws FileNotFoundException { //saves library on close
		File file = new File(FILE_SAVE);
		try {
			java.io.PrintWriter output = new java.io.PrintWriter(file);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm"); //date format found from stackoverflow
			for (int i = 0; i < library.size(); i++) {
				output.print(i + "|" + library.get(i).getTitle() + "|" + library.get(i).getAuthor() + "|" + library.get(i).isAvailable() + "|");
				if (library.get(i).getDateLoaned() == null) {
					output.print("null|");
				} else {
					output.print(sdf.format(library.get(i).getDateLoaned() + "|"));
				}
				output.println(sdf.format(library.get(i).getDateCreated()));
			}
			output.close();
		} catch (FileNotFoundException ex) {
			throw new FileNotFoundException("System could not find the file specified.");
		} 
	}
	@SuppressWarnings("deprecation")
	public static String formatDate(Date date) {
		return ((date.getMonth() + 1) + "/" + date.getDate() + "/" + (date.getYear() + 1900));
	}
	
	@SuppressWarnings("deprecation")
	public static String formatTime(Date date) {
		if (date.getHours() > 12) {
			return ((date.getHours() - 12) + ":" + date.getMinutes() + " PM");
		}
		else if (date.getHours() == 0) {
			return (("12: " + date.getMinutes() + " AM"));
		}
		else {
			return (date.getHours() + ":" + date.getMinutes() + " AM");
		}
	}
}