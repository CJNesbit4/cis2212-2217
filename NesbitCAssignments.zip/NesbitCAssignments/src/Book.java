import java.util.Date;
import java.util.Scanner;

public class Book {
	private String title;
	private String author;
	public boolean available;
	public Date dateLoaned;
	
	public int timesLoaned;
	public Date dateCreated;
	
	Book() {
		this.title = "";
		this.author = "";
		this.available = false; //false because no data
		this.dateLoaned = null; 
		this.timesLoaned = 0;
		this.dateCreated = new Date();
	}
	Book(String title, String author) {
		this.title = title;
		this.author = author;
		available = true; //true if created
		this.dateLoaned = null;
		timesLoaned = 0;
		dateCreated = new Date();
	}
	
	//ACCESSORS
	String getTitle() {
		return this.title;
	}
	String getAuthor() {
		return this.author;
	}
	boolean isAvailable() {
		return this.available;
	}
	Date getDateLoaned() {
		return this.dateLoaned;
	}
	int getTimesLoaned() {
		return this.timesLoaned;
	}
	Date getDateCreated() {
		return this.dateCreated;
	}
	
	//MUTATORS
	void changeTitle(String title) {
		this.title = title;
		return;
	}
	void changeAuthor(String author) {
		this.author = author;
		return;
	}
	void checkOut() {
		this.timesLoaned++;
		this.available = false;
		this.dateLoaned = new Date();
		return;
	}
	void bookReturn() {
		this.available = true;
		return;
	}

	public static void main(String[] args) {
		int userSelect = 0;
		Scanner input = new Scanner(System.in);
		Book[] library = new Book[100];
		String search = "";
		int index = -1;
		int searchMode = 0;
		
		while (userSelect != 8) {
			System.out.println("PULAU JAWA LIBRARY");
			System.out.println("1. Add a book");
			System.out.println("2. Remove a book");
			System.out.println("3. List all books and availability");
			System.out.println("4. Search");
			System.out.println("5. Check out a book");
			System.out.println("6. Return a book");
			System.out.println("7. View book details from index");
			System.out.println("8. Quit");
			System.out.print("Enter your selection: ");
			userSelect = input.nextInt();
			
			if (userSelect < 1 || userSelect > 8) {
				System.out.println("Your input was out of range. Please enter a valid number.");
			}
			
			switch (userSelect) {
			case 1:
				if (getLength(library) == 100) {
					System.out.println("The library has hit the maximum of 100 books stored, try removing some!");
					break;
				}
				addBook(library);
				break;
			case 2:
				int removeMode = 0;
				search = "";
				System.out.println("Warning: This removes a book completely. If you meant to check it out, quit this menu and select Option 5 in the Main Menu.");
				
				while (removeMode != 4) {
					System.out.println("1. Remove by Title");
					System.out.println("2. Remove by Author");
					System.out.println("3. Remove by Index");
					System.out.println("4. Quit");
					System.out.print("Enter your selection: ");
					removeMode = input.nextInt();
					
					if (removeMode < 1 || removeMode > 4) {
						System.out.println("Your input was out of range. Please enter a valid number.");
					}
					
					switch(removeMode) {
					case 1:
						System.out.print("Enter the title of the book you wish to remove: ");
						search = input.nextLine();
						if (search(library, search, 1) == -1) {
							System.out.println("The library does not contain a book with the title " + search + ".");
							break;
						}
						else {
							removeBook(library, search(library, search, 1));
						}
						break;
					case 2:
						System.out.print("Enter the author of the book you wish to remove: ");
						search = input.nextLine();
						if (search(library, search, 2) == -1) {
							System.out.println("The library does not contain a book with the author " + search + ".");
							break;
						}
						else {
							removeBook(library, search(library, search, 2));
						}
						break;
					case 3:
						System.out.print("Enter the index of the book you wish to remove: ");
						index = input.nextInt();
						if (index >= getLength(library)) {
							System.out.println("The library does not contain a book with index " + index + ".");
							break;
						}
						removeBook(library, index);
						break;
					case 4:
						break;
					default:
						break;
					}
				}
				break;
			case 3:
				int availableCount = 0;
				System.out.println("Pulau Jawa Library Catalog: ");
				for (int i = 0; i < getLength(library); i++) {
					System.out.print(i + ": " + library[i].getTitle() + " by " + library[i].getAuthor() + ".");
					if (library[i].isAvailable()) {
						System.out.println(" Available: Yes");
						availableCount++;
					}
					else {
						System.out.println(" Available: No");
					}
				}
				System.out.println("Total Available: " + availableCount + ". Total Unavailable: " + (getLength(library) - availableCount) + ".");
				break;
			case 4:
				searchMode = 0;
				search = "";
				index= -1;
				
				while (searchMode != 3) {
					System.out.println("Search Options:");
					System.out.println("1. Search by title");
					System.out.println("2. Search by author");
					System.out.println("3. Quit Search");
					System.out.print("Enter your selection: ");
					searchMode = input.nextInt();
					
					if (searchMode < 1 || searchMode > 3) {
						System.out.println("Your input was out of range. Please enter a valid number.");
					}
					input.nextLine();
					
					switch(searchMode) {
					case 1:
						System.out.print("Enter the title you wish to search for: ");
						search = input.nextLine();
						index = search(library, search, searchMode);
						break;
					case 2:
						System.out.print("Enter the author you wish to search for: ");
						search = input.nextLine();
						index = search(library, search, searchMode);
						break;
					case 3:
						break;
					default:
						break;
					}
					
					if (index == -1) {
						System.out.println("Your search '" + search + "' did not return any results.");
					}
					else {
						displayInfo(library, index);
					}
				}
				break;
			case 5: //check out
				searchMode = 0;
				search = "";
				index = -1;
				
				while (searchMode != 4) {
					System.out.println("Check out Options:");
					System.out.println("1. Check out by title");
					System.out.println("2. Check out by author");
					System.out.println("3. Check out by index");
					System.out.println("4. Quit Check out");
					System.out.print("Enter your selection: ");
					searchMode = input.nextInt();
					input.nextLine();
					
					if (searchMode < 1 || searchMode > 4) {
						System.out.println("Your input was out of range. Please enter a valid number.");
					}
					
					switch (searchMode) {
					case 1:
						System.out.print("Enter the title of the book you wish to check out: ");
						search = input.nextLine();
						if (search(library, search, 1) == -1) {
							System.out.println("The library does not contain a book with the title " + search + ".");
							break;
						}
						else {
							if (!library[search(library, search, 1)].isAvailable()) {
								System.out.println("The book " + library[search(library, search, 1)].getTitle() + " is not available, so you cannot check it out.");
								System.out.println("The book was last checked out on " + formatDate(library[search(library, search, 1)].getDateLoaned()) + ".");
							}
							else {
								library[search(library, search, 1)].checkOut();
								System.out.println("Succesfully checked out " + search + ".");
							}
						}
						break;
					case 2:
						System.out.print("Enter the author of the book you wish to check out: ");
						search = input.nextLine();
						if (search(library, search, 2) == -1) {
							System.out.println("The library does not contain a book with the author " + search + ".");
							break;
						}
						else {
							if (!library[search(library, search, 2)].isAvailable()) {
								System.out.println("The book by " + library[search(library, search, 2)].getAuthor() + " is not available, so you cannot check it out.");
								System.out.println("The book was last checked out on " + formatDate(library[search(library, search, 2)].getDateLoaned()) + ".");
							}
							else {
								library[search(library, search, 2)].checkOut();
								System.out.println("Succesfully checked out " + search + ".");
							}
						}
						break;
					case 3:
						System.out.print("Enter the index of the book you wish to check out: ");
						index = input.nextInt();
						if (index >= getLength(library)) {
							System.out.println("The library does not contain a book with index " + index + ".");
							break;
						}
						
						if (!library[index].isAvailable()) {
							System.out.println("The book is not available, so you cannot check it out.");
							System.out.println("The book was last checked out on " + formatDate(library[search(library, search, 3)].getDateLoaned()) + ".");
						}
						else {
							library[index].checkOut();
							System.out.println("Successfully checked out book with index " + index + ".");
						}
						break;
					case 4:
						break;
					default:
						break;
					}
				}
				break;
			case 6: //return
				searchMode = 0;
				search = "";
				index = -1;
				
				while (searchMode != 4) {
					System.out.println("Return Options:");
					System.out.println("1. Return by title");
					System.out.println("2. Return by author");
					System.out.println("3. Return by index");
					System.out.println("4. Quit Return");
					System.out.print("Enter your selection: ");
					searchMode = input.nextInt();
					input.nextLine();
					
					if (searchMode < 1 || searchMode > 4) {
						System.out.println("Your input was out of range. Please enter a valid number.");
					}
					
					switch(searchMode) {
					case 1:
						System.out.print("Enter the title of the book you wish to return: ");
						search = input.nextLine();
						if (search(library, search, 1) == -1) {
							System.out.println("The library does not contain a book with the title " + search + ".");
							break;
						}
						else {
							if (library[search(library, search, 1)].isAvailable()) {
								System.out.println("The book " + library[search(library, search, 1)].getTitle() + " is not checked out yet, so you cannot return it.");
							}
							else {
								library[search(library, search, 1)].bookReturn();
								System.out.println("Succesfully returned " + search + ".");
							}
						}
						break;
					case 2:
						System.out.print("Enter the author of the book you wish to return: ");
						search = input.nextLine();
						if (search(library, search, 2) == -1) {
							System.out.println("The library does not contain a book with the author " + search + ".");
							break;
						}
						else {
							if (library[search(library, search, 2)].isAvailable()) {
								System.out.println("The book by " + library[search(library, search, 2)].getAuthor() + " is not checked out yet, so you cannot return it.");
							}
							else {
								library[search(library, search, 2)].bookReturn();
								System.out.println("Succesfully returned " + search + ".");
							}
						}
						break;
					case 3:
						System.out.print("Enter the index of the book you wish to return: ");
						index = input.nextInt();
						if (index >= getLength(library)) {
							System.out.println("The library does not contain a book with index " + index + ".");
							break;
						}
						
						if (library[index].isAvailable()) {
							System.out.println("The book is not checked out yet, so you cannot return it.");
						}
						else {
							library[index].bookReturn();
							System.out.println("Successfully returned book with index " + index + ".");
						}
						break;
					case 4:
						break;
					default:
						break;
					}
				}
				break;
			case 7: //search by index
				index = 0;
				System.out.print("Enter the index of the book: ");
				index = input.nextInt();
				if (index >= getLength(library)) {
					System.out.println("There is no book with that index!");
					break;
				}
				displayInfo(library, index);
				break;
			case 8: //quit
				System.out.println("Thank you for visiting the Palau Jawa Library!");
				input.close();
				return;
			default:
				break;
			}
		}
		input.close();
		return;
	}
	
	//methods
	public static void addBook(Book[] library) {
		int userSelect = 0;
		Scanner input = new Scanner(System.in);
		
		while (userSelect != 3) {
			System.out.println("Select an option: ");
			System.out.println("1. Add a book normally");
			System.out.println("2. Add 10 default books (for ease of grading/testing)");
			System.out.println("3. Return to Main Menu");
			System.out.print("Enter your selection: ");
			userSelect = input.nextInt();
			
			if (userSelect < 1 || userSelect > 3) {
				System.out.println("Your input was out of range. Please enter a valid number.");
			}
			
			switch (userSelect) { //java is potentially pass by value, check later for bugs
			case 1:
				Book userBook = new Book();
				input.nextLine();
				System.out.print("Enter the name of the book: "); 
				userBook.changeTitle(input.nextLine());
				System.out.print("Enter the author of the book: ");
				userBook.changeAuthor(input.nextLine());
				userBook.bookReturn();
				
				library[getLength(library)] = userBook;
				System.out.println("Book successfully added!");
				break;
			case 2:
				if (getLength(library) >= 90) {
					System.out.println("There is not enough room to add 10 more default books!");
					break;
				}
				
				library[getLength(library)] = new Book("Huckleberry Finn","Mark Twain");
				library[getLength(library)] = new Book("How the Grinch Stole Christmas","Dr. Seuss");
				library[getLength(library)] = new Book("Old Yeller","Fred Gipson");
				library[getLength(library)] = new Book("How to Win at Chess","Levy Rozman");
				library[getLength(library)] = new Book("Java: A Beginner's Guide","Herbert Schilt");
				library[getLength(library)] = new Book("Western Civilizations","Joshua Cole, Carol Symes");
				library[getLength(library)] = new Book("The Decline and Fall of the Roman Empire","Edward Gibbon");
				library[getLength(library)] = new Book("The Wizard of Oz","Frank Baum");
				library[getLength(library)] = new Book("The Hobbit","J. R. R. Tolkien");
				library[getLength(library)] = new Book("The Yellow House Mystery","Gertrude Warner");
				System.out.println("Added 10 default books.");
				break;
			case 3:
				System.out.println("Returning to Main Menu.");
				break;
			default:
				break;
			}
		}
		return;
	} //end addBook
	
	public static void removeBook(Book[] library, int index) {
		for (int i = index; i < getLength(library) - 1; i++) { //
			library[i] = library[i + 1];
		}
		library[(getLength(library) - 1)] = null;
	} //end removeBook
	
	public static int search(Book[] library, String search, int mode) { //returns the index of the search
		switch (mode) {
		case 1: //title
			for (int i = 0; i < getLength(library); i++) {
				if (library[i].getTitle().equalsIgnoreCase(search)) {
					return i;
				}
			}
			break;
		case 2: //author
			for (int i = 0; i < getLength(library); i++) {
				if (library[i].getAuthor().equalsIgnoreCase(search)) {
					return i;
				}
			}
			break;
		default:
			break;
		}
		return -1; //no result found
	}
	
	public static int getLength(Book[] library) {
		int i;
		for (i = 0; i < 100; i++) {
			if (library[i] == null) {
				return i;
			}
		}
		i++; //full
		return i;
	}
	
	public static void displayInfo(Book[] library, int index) {
		System.out.println("Book Details at Index " + index + ":");
		System.out.println("Title: " + library[index].getTitle());
		System.out.println("Author: " + library[index].getAuthor());
		if (library[index].isAvailable()) {
			System.out.println("Available: Yes");
		}
		else {
			System.out.println("Available: No. Last checkout: " + formatDate(library[index].getDateLoaned()));
		}
		
		System.out.println("Times checked out: " + library[index].getTimesLoaned());
		System.out.println("Date arrived at library (MM/DD/YYYY): " + formatDate(library[index].getDateCreated()) + " at " + formatTime(library[index].getDateCreated()));
	}
	
	@SuppressWarnings("deprecation")
	public static String formatDate(Date date) {
		return ((date.getMonth() + 1) + "/" + date.getDate() + "/" + (date.getYear() + 1900));
	}
	
	@SuppressWarnings("deprecation")
	public static String formatTime(Date date) {
		if (date.getHours() > 12) {
			return ((date.getHours() - 12) + ":" + date.getMinutes() + " PM");
		}
		else if (date.getHours() == 0) {
			return (("12: " + date.getMinutes() + " AM"));
		}
		else {
			return (date.getHours() + ":" + date.getMinutes() + " AM");
		}
	}
}