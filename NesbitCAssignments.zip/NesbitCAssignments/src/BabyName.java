import java.util.Scanner;
import java.io.*;
import java.util.ArrayList;

public class BabyName {
	public static void main(String[] args) throws IOException {
		String fileName = "";
		Scanner input = new Scanner(System.in);
		
		ArrayList<String> boyNames = new ArrayList<>();
		ArrayList<String> girlNames = new ArrayList<>();
		int boyCount = 0;
		int girlCount = 0;
		
		System.out.print("Enter the file name: ");
		fileName = input.nextLine();
		
		try (Scanner fileScanner = new Scanner(new File(fileName))) {
			while (fileScanner.hasNext()) {
				fileScanner.next(); //Number count on side?
				
				boyNames.add(fileScanner.next()); //add boy name
				boyCount++;
				fileScanner.next(); //number of said boy name, stored nowhere because it's not needed
				
				girlNames.add(fileScanner.next()); //add girl name
				girlCount++;
				fileScanner.next(); //number of said girl name, also stored nowhere because it's not needed
			}
			fileScanner.close();
			System.out.println("There were " + boyCount + " boy names and " + girlCount + " girl names found.");
			System.out.print("Boy names: ");
			for (int i = 0; i < boyNames.size(); i++) { //print boy array list
				System.out.print(boyNames.get(i) + ", ");
			}
			System.out.println(".");
			System.out.print("Girl names: ");
			for (int i = 0; i < girlNames.size(); i++) { //print girl name array list
				System.out.print(girlNames.get(i) + ", ");
			}
			System.out.println(".");
		}
		catch (java.io.FileNotFoundException ex) { //Throws if the user enters anything but babynameranking2001.txt
			System.out.println("File with name " + fileName + " not found!");
		}
		catch (java.io.IOException ex) { //for other IO errors that could occur (I personally found none while testing)
			System.out.println("IO Errors");
		}
		input.close();
	}

}
