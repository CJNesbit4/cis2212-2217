public class Circle {
	private double x;
	private double y;
	private double radius;
	
	public Circle() {
		this.x = 0;
		this.y = 0;
		this.radius = 1;
	}
	public Circle(double x, double y, double radius) {
		this.x = x;
		this.y = y;
		this.radius = radius;
	}
	
	public double getX() {
		return this.x;
	}
	public double getY() {
		return this.y;
	}
	public double getRadius() {
		return this.radius;
	}
	
	public double getArea() {
		return (Math.PI * Math.pow(radius, 2));
	}
	public double getPerimeter() {
		return (Math.PI * radius * 2);
	}
	public boolean contains(double x, double y) {
		if (Math.sqrt((Math.pow((x - this.x), 2) + Math.pow((y - this.y), 2))) < this.radius) {
			return true;
		}
		return false;
	}
	public boolean contains(Circle circle) {
		if (contains((circle.getX() + circle.getRadius()), circle.getY())
				&& contains((circle.getX() - circle.getRadius()), circle.getY())
				&& contains(circle.getX(), (circle.getY() + circle.getRadius()))
				&& contains(circle.getX(), (circle.getY() - circle.getRadius()))) {
			return true;
		}
		return false;
	}
	public boolean overlaps(Circle circle) {
		if (Math.sqrt((Math.pow((circle.getX() - this.x), 2) + Math.pow((circle.getY() - this.y), 2))) <= (this.radius + circle.getRadius())) {
			return true;
		}
		return false;
	}
	
	public static void main(String[] args) {
		Circle c1 = new Circle(2.0,2.0,5.5); //given by instructor
		System.out.println("Circle perimeter is " + c1.getPerimeter());
		System.out.println("Circle area is " + c1.getArea());
		
		if (c1.contains(3,3)) {
			System.out.println("Circle contains the point 3,3");
		}
		else {
			System.out.println("Circle does not contain the point 3,3");
		}
		
		if (c1.contains(new Circle(4,5,10.5))) {
			System.out.println("Circle contains the circle with radius 10.5 centered at 4,5");
		}
		else {
			System.out.println("Circle does not contain the circle with radius 10.5 centered at 4,5");
		}
		
		if (c1.overlaps(new Circle(3,5,2.3))) {
			System.out.println("Circle overlaps with the circle with radius 2.3 centered at 3,5");
		}
		else {
			System.out.println("Circle does not overlap with the circle with radius 2.3 centered at 3,5");
		}
	}
}
