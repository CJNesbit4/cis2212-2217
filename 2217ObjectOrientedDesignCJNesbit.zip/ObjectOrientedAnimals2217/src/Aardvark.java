
public class Aardvark extends AnimaliaOrganism implements AntEater {
	
	/**the habitat of the aardvark */
	private String habitat;
	
	/**
	 * 
	 * @param habitat
	 * @param phylumName
	 * @param className
	 * @param orderName
	 * @param familyName
	 * @param genusName
	 * @param speciesName
	 * @param organismName
	 * @param extinct
	 */
	public Aardvark(String habitat, String phylumName, String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		super(phylumName, className, orderName, familyName, genusName, speciesName, organismName, extinct);
		this.habitat = habitat;
	}
	
	/**
	 * returns the current habitat of the aardvark
	 * @return the current habitat of the aardvark
	 */
	public String getHabitat() {
		return habitat;
	}

	/**
	 * sets a new habitat for the aardvark
	 * @param habitat the desired new habitat of the aardvark
	 */
	public void setHabitat(String habitat) {
		this.habitat = habitat;
	}

	/**
	 * returns a formatted string with all the details about the aardvark
	 * @return the inherited toString method with the habitat appended at the start
	 */
	public String toString() {
		return "Habitat: " + getHabitat() + ", " + super.toString();
	}

	/**
	 * Allows an aardvark to eat an ant
	 * @param the ant to be eaten
	 * @return a string notifying what aardvark is eating which ant
	 */
	public String eatAnt(Ant ant) {
		return ("The aardvark " + this.getOrganismName() + " is currently eating the ant " + ant.getOrganismName() + ".");
	}
}
