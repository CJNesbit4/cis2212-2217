
public abstract class PlantaeOrganism extends EukaryaOrganism { //KINGDOM: PLANTAE
	
	/**the division name of the plantae organism */
	private String divisionName;
		
	/**
	 * Constructor that fully constructs a Plantae Organism given all the needed details
	 * @param divisionName the division name
	 * @param className the class name
	 * @param orderName the order name
	 * @param familyName the family name
	 * @param genusName the genus name
	 * @param speciesName the species name
	 * @param organismName the organism name
	 * @param extinct if the organism is extinct or not
	 */
	public PlantaeOrganism(String divisionName, String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		super(className, orderName, familyName, genusName, speciesName, organismName, extinct);
		this.divisionName = divisionName;
	}

	/**
	 * returns the division name of the organism
	 * @return the division name of the organism
	 */
	public String getDivisionName() {
		return divisionName;
	}
	
	/**
	 * sets the division of the plantae organism
	 * @param divisionName the new division of the organism
	 */
	public void setDivisionName(String divisionName) {
		this.divisionName = divisionName;
	}
	
	/**
	 * returns a formatted string with all the details about the plantae organism
	 * @return the inherited toString method with the Plantae Kingdom and plantae division appended at the start
	 */
	public String toString() {
		return "Kingdom: Plantae, Division: " + getDivisionName() + ", " + super.toString();
	}
}
