
public abstract class AnimaliaOrganism extends EukaryaOrganism { //KINGDOM: ANAMILIA
	public String phylumName;
	
	/**
	 * Constructor that fully constructs an Animalia Organism given all the needed details
	 * @param phylumName the phylum name
	 * @param className the class name
	 * @param orderName the order name
	 * @param familyName the family name
	 * @param genusName the genus name
	 * @param speciesName the species name
	 * @param organismName the organism name
	 * @param extinct if the organism is extinct or not
	 */
	public AnimaliaOrganism(String phylumName, String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		super(className, orderName, familyName, genusName, speciesName, organismName, extinct);
		this.phylumName = phylumName;
	}

	/**
	 * returns the phlyum name of the organism
	 * @return the phlyum name of the organism
	 */
	public String getPhylumName() {
		return phylumName;
	}

	/**
	 * sets the phylum of the animalia organism
	 * @param phylumName the new phylum of the organism
	 */
	public void setPhylumName(String phylumName) {
		this.phylumName = phylumName;
	}

	/**
	 * returns a formatted string with all the details about the animalia organism
	 * @return the inherited toString method with the Anamalia Kingdom and anamalia phylum appended at the start
	 */
	public String toString() {
		return "Kingdom: Anamilia, Phylum: " + getPhylumName() + ", " + super.toString();
	}
}
