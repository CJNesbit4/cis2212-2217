
public class Ant extends AnimaliaOrganism {
	
	/**caste rank of the ant */
	private String casteRank;
	
	/**
	 * constructor for an ant given all the following details
	 * @param casteRank the caste rank of the ant
	 * @param phylumName the phylum name of the ant, because it is an animalia organism
	 * @param className the class name
	 * @param orderName the order name
	 * @param familyName the family name
	 * @param genusName the genus name
	 * @param speciesName the species name
	 * @param organismName the organism name
	 * @param extinct if the organism is extinct or not
	 */
	public Ant(String casteRank, String phylumName, String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		super(phylumName, className, orderName, familyName, genusName, speciesName, organismName, extinct);
		this.casteRank = casteRank;
	}

	/**
	 * returns the caste rank of the ant
	 * @return the caste rank of the ant
	 */
	public String getCasteRank() {
		return casteRank;
	}

	/**
	 * sets the caste rank of the ant
	 * @param casteRank the desired new caste rank of the ant
	 */
	public void setCasteRank(String casteRank) {
		this.casteRank = casteRank;
	}
	
	/**
	 * returns a formatted string with all the details about the ant
	 * @return the inherited toString method with the caste rank appended at the start
	 */
	public String toString() {
		return "Caste Rank: " + getCasteRank() + ", " + super.toString();
	}
}
