
public interface AntEater {
	String eatAnt(Ant ant);
}
