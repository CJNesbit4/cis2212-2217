
public class VenusFlyTrap extends PlantaeOrganism implements AntEater {
	/**Trap size of the venus fly trap in any units */
	private double trapSize;
	
	/**
	 * constructor for a venus fly trap given all the following details
	 * @param trapSize the trap size of the venus fly trap
	 * @param divisionName The division name of the venus fly trap, because it is a plantae organism
	 * @param className the class name
	 * @param orderName the order name
	 * @param familyName the family name
	 * @param genusName the genus name
	 * @param speciesName the species name
	 * @param organismName the organism name
	 * @param extinct if the organism is extinct or not
	 */
	public VenusFlyTrap(double trapSize, String divisionName, String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		super(divisionName, className, orderName, familyName, genusName, speciesName, organismName, extinct);
		this.trapSize = trapSize;
	}

	/**
	 * returns the trap size of the venus fly trap
	 * @return the trap size of the venus fly trap
	 */
	public double getTrapSize() {
		return trapSize;
	}

	/**
	 * sets the trap size of the venus fly trap
	 * @param trapSize the trap size of the venus fly trap
	 */
	public void setTrapSize(double trapSize) {
		this.trapSize = trapSize;
	}
	
	/**
	 * returns a formatted string with all the details about the venus fly trap 
	 * @return the inherited toString method with the Trap size appended at the start
	 */
	public String toString() {
		return "Trap Size: " + getTrapSize() + ", " + super.toString();
	}
	
	/**
	 * Allows a venus fly trap to eat an ant
	 * @param the ant to be eaten
	 * @return a string notifying what fly trap is eating which ant
	 */
	public String eatAnt(Ant ant) {
		return ("The venus fly trap " + this.getOrganismName() + " is currently eating the ant " + ant.getOrganismName() + ".");
	}

}
