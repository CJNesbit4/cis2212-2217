//CJ Nesbit
//CIS 2217 Object-Oriented Design
public abstract class EukaryaOrganism {
	
	/** class name of organism */
	private String className;
	
	/** order name of organism */
	private String orderName;
	
	/** family name of organism */
	private String familyName;
	
	/** genus name of organism */
	private String genusName;
	
	/** species name of organism */
	private String speciesName;
	
	/** actual name of organism */
	private String organismName;
	
	/**extinction status of organism*/
	private boolean extinct; //where T = extinct
	
	/**
	 * Constructor that fully constructs a Eukarya Organism given all the needed details
	 * @param className the class name
	 * @param orderName the order name
	 * @param familyName the family name
	 * @param genusName the genus name
	 * @param speciesName the species name
	 * @param organismName the organism name
	 * @param extinct if the organism is extinct or not
	 */
	public EukaryaOrganism(String className, String orderName, String familyName, String genusName, String speciesName, String organismName, boolean extinct) {
		this.className = className;
		this.orderName = orderName;
		this.familyName = familyName;
		this.genusName = genusName;
		this.speciesName = speciesName;
		this.organismName = organismName;
		this.extinct = extinct;
	}

	/**
	 * returns the class name of the organism
	 * @return the class name of the organism
	 */
	public String getClassName() {
		return className;
	}
	
	/**
	 * sets the class name of the organism
	 * @param className the class name of the organism
	 */
	public void setClassName(String className) {
		this.className = className;
	}

	/**
	 * returns the order name of the organism
	 * @return the order name of the organism
	 */
	public String getOrderName() {
		return orderName;
	}

	/**
	 * sets the order name of the organism
	 * @param orderName the order name of the organism
	 */
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	/**
	 * returns the family name of the organism
	 * @return the family name of the organism
	 */
	public String getFamilyName() {
		return familyName;
	}

	/**
	 * sets the family name of the organism
	 * @param familyName the family name of the organism
	 */
	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	/**
	 * returns the genus name of the organism
	 * @return the genus name of the organism
	 */
	public String getGenusName() {
		return genusName;
	}

	/**
	 * sets the genus name of the organism
	 * @param genusName the genus name of the organism
	 */
	public void setGenusName(String genusName) {
		this.genusName = genusName;
	}

	/**
	 * returns the species name of the organism
	 * @return the species name of the organism
	 */
	public String getSpeciesName() {
		return speciesName;
	}

	/**
	 * sets the species name of the organism
	 * @param speciesName the species name of the organism
	 */
	public void setSpeciesName(String speciesName) {
		this.speciesName = speciesName;
	}

	/**
	 * returns the actual name of the organism
	 * @return the actual name of the organism
	 */
	public String getOrganismName() {
		return organismName;
	}

	/**
	 * sets the actual name of the organism
	 * @param organismName the actual name of the organism
	 */
	public void setOrganismName(String organismName) {
		this.organismName = organismName;
	}

	/**
	 * returns if the organism is extinct
	 * @return true if the organism is extinct : false if the organism is not extinct
	 */
	public boolean isExtinct() {
		return extinct;
	}

	/**
	 * sets the extinction status of the organism
	 * @param extinct true if the organism is extinct : false if the organism is not extinct
	 */
	public void setExtinct(boolean extinct) {
		this.extinct = extinct;
	}
	
	/**
	 * formats the class data into a string
	 * @return A string with all the organism data in one line, each class member labeled with its name, separated by commas
	 */
	public String toString() {
		return "Class: " + getClassName() + ", Order: " + getOrderName() + ", Family: " + getFamilyName() + ", Genus: " + getGenusName() + ", Species: " + getSpeciesName() + ", Organism Name: " + getOrganismName() + ", Extinct: " + isExtinct();
	}
}
