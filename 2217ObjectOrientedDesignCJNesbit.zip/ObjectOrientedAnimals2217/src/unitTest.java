import static org.junit.Assert.*;

import org.junit.Test;

import junit.framework.Assert;

@SuppressWarnings("deprecation")
public class unitTest {

	@Test
	public void test() {
		Aardvark aardvark = new Aardvark("Semi-Arid", "Chordata", "Mammalia", "Tubulidentata", "Orycteropodidae", "Orycteropus", "Orycteropus after", "Aardvark", false);
		Ant ant = new Ant("Worker", "Anthropoda", "Insecta", "Hymenoptera", "Formicidae", "Formica", "Formica rufa", "Ant", false);
		VenusFlyTrap vft = new VenusFlyTrap(6.5, "Angiosperms", "Eduicots", "Caryophyllales", "Droseraceae", "Dionaea", "Dionaea mucipula", "Venus Fly Trap", false);
		
		//toString method testing
		Assert.assertEquals("Trap Size: 6.5, Kingdom: Plantae, Division: Angiosperms, Class: Eduicots, Order: Caryophyllales, Family: Droseraceae, Genus: Dionaea, Species: Dionaea mucipula, Organism Name: Venus Fly Trap, Extinct: false", vft.toString());
		Assert.assertEquals("Caste Rank: Worker, Kingdom: Anamilia, Phylum: Anthropoda, Class: Insecta, Order: Hymenoptera, Family: Formicidae, Genus: Formica, Species: Formica rufa, Organism Name: Ant, Extinct: false", ant.toString());
		Assert.assertEquals("Habitat: Semi-Arid, Kingdom: Anamilia, Phylum: Chordata, Class: Mammalia, Order: Tubulidentata, Family: Orycteropodidae, Genus: Orycteropus, Species: Orycteropus after, Organism Name: Aardvark, Extinct: false", aardvark.toString());
		
		//venus fly trap custom method test
		Assert.assertEquals(6.5, vft.getTrapSize());
		vft.setTrapSize(9.772);
		Assert.assertEquals(9.772, vft.getTrapSize());
		
		//eating method tests
		Assert.assertEquals("The venus fly trap Venus Fly Trap is currently eating the ant Ant.", vft.eatAnt(ant));
		Assert.assertEquals("The aardvark Aardvark is currently eating the ant Ant.", aardvark.eatAnt(ant));
		
		//testing names and eating methods again
		ant.setOrganismName("Bobby the Ant");
		Assert.assertEquals("The venus fly trap Venus Fly Trap is currently eating the ant Bobby the Ant.", vft.eatAnt(ant));
		Assert.assertEquals("The aardvark Aardvark is currently eating the ant Bobby the Ant.", aardvark.eatAnt(ant));
		//poor bobby the ant :(
		
		//ant caste test
		Assert.assertEquals("Worker", ant.getCasteRank());
		ant.setCasteRank("Queen");
		Assert.assertEquals("Queen", ant.getCasteRank());
		
		//aardvark becomes TV show star of House Hunters
		Assert.assertEquals("Semi-Arid", aardvark.getHabitat());
		aardvark.setHabitat("Grassland");
		Assert.assertEquals("Grassland", aardvark.getHabitat());
	}

}
