//CJ Nesbit
//Shapes Phase 2
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Color;

public class Box extends Shape{

	public Box() {
		super();
	}
	
	public Box(Point a, Point b, Color color) {
		super(a,b,color);
	}
	
	public void draw(Graphics g) {
		g.setColor(getColor());
		g.drawRect(Math.min(getA().x, getB().x), Math.min(getA().y, getB().y), Math.abs(getB().x - getA().x) , Math.abs(getB().y - getA().y));
	}
	
	public void moveTo(int x, int y) { //copied from book
		Point newB = new Point(x, y);
		this.setB(newB);
		repaint();
	}
}