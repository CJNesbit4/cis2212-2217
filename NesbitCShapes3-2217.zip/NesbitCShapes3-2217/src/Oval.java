//CJ Nesbit
//Shapes Phase 2
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Color;

public class Oval extends Shape{
	public Oval() {
		super();
	}
	
	public Oval(Point a, Point b, Color color) {
		super(a,b,color);
	}
	
	
	public void draw(Graphics g) {
		g.setColor(getColor());
		g.drawOval(Math.min(getA().x, getB().x), Math.min(getA().y, getB().y), Math.abs(getB().x - getA().x) , Math.abs(getB().y - getA().y));
	}
}
