//CJ Nesbit
//Shapes Phase 2
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;

import javax.swing.JComponent;
public abstract class Shape extends JComponent { 
	private Point a, b;
	private Color color;
	
	public Shape() {
		this.a = new Point(0,0);
		this.b = new Point(0,0);
		this.color = Color.red;
	}
	
	public Shape(Point a, Point b, Color color) {
		this.a = a;
		this.b = b;
		this.color = color;
	}
	
	public Point getA() {
		return a;
	}

	public void setA(Point a) {
		this.a = a;
	}

	public Point getB() {
		return b;
	}

	public void setB(Point b) {
		this.b = b;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public abstract void draw(Graphics g);
}
