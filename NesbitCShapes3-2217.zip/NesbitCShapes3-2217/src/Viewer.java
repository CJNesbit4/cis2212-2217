//CJ Nesbit
//Shapes Phase 2
import java.awt.BorderLayout;

import javax.swing.*;

public class Viewer extends JFrame {
	public Viewer() {
		JPanel panel = new ViewerFrame();
		add(panel);
	}
	
	public static void main(String[] args) {
		JFrame frame = new Viewer();
		frame.setTitle("Shapes Phase 2");
		
		JLabel statusBar = new JLabel("(E)rase (T)rails (L)ine (B)ox (O)val (C)olor (S)ave (R)estore"); //found on stack overflow - also does not interfere with the shape canvas
        frame.add(statusBar, BorderLayout.SOUTH);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(800,600);
		frame.setVisible(true);
	}
}
