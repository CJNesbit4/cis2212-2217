//CJ Nesbit
//Shapes Phase 2
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Color;

public class Line extends Shape {
	public Line() {
		super();
	}
	
	public Line(Point a, Point b, Color color) {
		super(a,b,color);
	}
	
	
	public void draw(Graphics g) {
		g.setColor(getColor());
		g.drawLine(getA().x, getA().y, getB().x, getB().y);
	}
}
