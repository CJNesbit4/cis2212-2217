//CJ Nesbit
//Shapes Phase 2
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;

public class ViewerFrame extends JPanel {
	private enum ShapeType {LINE, BOX, OVAL} //enum for rubric points
	
	private ShapeType currentShapeType = ShapeType.LINE;
	private Shape currentShape;
	private boolean trailsEnabled = false;
	private Color currentColor;
	private final ArrayList<Shape> shapes = new ArrayList<>();

	public ViewerFrame() {
		currentColor = Color.RED;
		currentShape = new Line(new Point(0,0), new Point(0, 0), currentColor);
		setVisible(true);
        setFocusable(true);      
        
        //handler initialize 
        MouseHandler mouseHandler = new MouseHandler();
        addMouseListener(mouseHandler);
        addMouseMotionListener(mouseHandler); //adapter methods from book 
        
        addKeyListener(new KeyHandler());
    }

	private class KeyHandler extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (Character.toUpperCase(e.getKeyChar())) {
                case 'E':
                    shapes.clear();
                    currentShape = null;
                    repaint();
                    break;
                case 'T':
                    trailsEnabled = !trailsEnabled;
                    break;
                case 'L':
                    currentShapeType = ShapeType.LINE;
                    break;
                case 'B':
                	currentShapeType = ShapeType.BOX;
                    break;
                case 'O':
                	currentShapeType = ShapeType.OVAL;
                    break;
                case 'C':
                    Color chosenColor = JColorChooser.showDialog(ViewerFrame.this, "Choose a color", currentColor);
                    if (chosenColor != null) {
                        currentColor = chosenColor;
                    }
                    break;
                case 'S': 
                	JFileChooser saveChoice = new JFileChooser(new File("C:\\Documents\\"));
                	saveChoice.setFileFilter(new FileNameExtensionFilter("Binary/Data Files", "bin", "dat"));
                	int saverResult = saveChoice.showSaveDialog(null);
                	if (saverResult == JFileChooser.APPROVE_OPTION) {
                		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(saveChoice.getSelectedFile()))) {
                			out.writeObject(shapes);
                		} catch (IOException ex) {
                			System.out.println("Error: General I/O Error when writing the stream header.");
                			System.out.println("The file corrupted when attempting to write the stream header. Please try to save again.");
                		} catch (SecurityException ex) {
                			System.out.println("Error: File Security Error.");
                			System.out.println("The program may not have sufficient permissions to read the file.");
                		} catch (NullPointerException ex) {
                			System.out.println("Error: Null Pointer Exception.");
                			System.out.println("The file requested to load was null.");
                		}
                	} 
                	break;
                case 'R':
                	JFileChooser restoreChoice = new JFileChooser(new File("C:\\Documents\\"));
                	restoreChoice.setFileFilter(new FileNameExtensionFilter("Binary/Data Files", "bin", "dat"));
                	int restoreResult = restoreChoice.showOpenDialog(null);
                	if (restoreResult == JFileChooser.APPROVE_OPTION) {
                		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(restoreChoice.getSelectedFile()))) {
                			shapes.clear(); //if I don't do this you can load a drawing on top of existing ones which I didn't figure out the first time through 
                			shapes.addAll((ArrayList<Shape>) in.readObject());
                			//eclipse doesn't like this but it hasn't caused any problems at all so I'm gonna continue casting like this
                			repaint();
                		} catch (ClassNotFoundException ex) {
                			System.out.println("Error loading the shapes class.");
                			System.out.println("Please restart or restore the program to a previous stable state.");
                		} catch (StreamCorruptedException ex) {
                			System.out.println("Error: Corrupted Stream.");
                			System.out.println("You may have tried to load a binary file that was generated from other software.");
                			System.out.println("Or your file was saved improperly and was corrupted.");
                		} catch (IOException ex) {
                			System.out.println("Error: General I/O Error when reading the stream header.");
                			System.out.println("The file may have been corrupted during saving or tampered with at some point.");
                		} catch (SecurityException ex) {
                			System.out.println("Error: File Security Error.");
                			System.out.println("The program may not have sufficient permissions to read the file.");
                		} catch (NullPointerException ex) {
                			System.out.println("Error: Null Pointer Exception.");
                			System.out.println("The file requested to load was null.");
                		} catch (IllegalStateException ex) {
                			System.out.println("Error: Illegal state exception loading the Object Input Stream. Details:");
                			ex.printStackTrace();
                			//Throughout my testing in the program I have never gotten this exception to throw and I don't know how to
                			//but its listed as a potential throw by ObjectInputStream so i put it here just in case
                		}
                	}
                	break;
            }
        }
    }
	
    
	// Override paintComponent for custom drawing
    public void paint(Graphics g) {
        super.paint(g);
        // Draw all existing shapes
        for (Shape shape : shapes) {
            shape.draw(g);
        }
        // Draw the current shape being drawn
        if (currentShape != null) {
            currentShape.draw(g);
        }
    }

	//I used adapter just so I wouldn't have to add unnecessary methods like it said in the rubric
    //plus it was easier to follow the adapter tutorial in the book than it was to follow the listener one
    private class MouseHandler extends MouseAdapter {
        @Override
        public void mousePressed(MouseEvent e) {
            Point startPoint = e.getPoint();
            Point endPoint = e.getPoint();
            switch (currentShapeType) {
            //this might honestly leak memory by calling new if trails are off, I honestly don't know if currentShape is discarded automatically
            //let me know if it does/how to fix it/if it even is an issue
                case LINE:
                    currentShape = new Line(startPoint, endPoint, currentColor);
                    break;
                case BOX:
                    currentShape = new Box(startPoint, endPoint, currentColor);
                    break;
                case OVAL:
                    currentShape = new Oval(startPoint, endPoint, currentColor);
                    break;
            }
            repaint();
        }

        @Override
        public void mouseDragged(MouseEvent e) {
            if (currentShape != null) {
                currentShape.setB(e.getPoint());
                if (trailsEnabled) {
                	//this should not leak memory as shapes is cleared upon pressing E
                    Shape trailShape = createShape(currentShape.getA(), e.getPoint());
                    if (trailShape != null) {
                        shapes.add(trailShape);
                    }
                }
                repaint();
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            if (currentShape != null) {
                currentShape.setB(e.getPoint());
                shapes.add(currentShape);
                currentShape = null;
                repaint();
            }
        }
    }
	
    private Shape createShape(Point a, Point b) {
    	//trails method
    	//this is just a copy of the code I put in mousePressed for object creation
        switch (currentShapeType) {
            case LINE:
                return new Line(a, b, currentColor);
            case BOX:
                return new Box(a, b, currentColor);
            case OVAL:
                return new Oval(a, b, currentColor);
            default:
                return null;
        }
    } 
}
